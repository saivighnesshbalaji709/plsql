from sqlalchemy import Column, Integer, String, Float, DateTime, Boolean, ForeignKey, Text, JSON
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from .database import Base

class User(Base):
    __tablename__ = "users"
    
    id = Column(Integer, primary_key=True, index=True)
    email = Column(String, unique=True, index=True, nullable=False)
    username = Column(String, unique=True, index=True, nullable=False)
    full_name = Column(String, nullable=False)
    hashed_password = Column(String, nullable=False)
    role = Column(String, nullable=False)  # trainer, ld_hr, stakeholder, admin
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    
    # Relationships
    alerts = relationship("Alert", back_populates="user")
    audit_logs = relationship("AuditLog", back_populates="user")

class Batch(Base):
    __tablename__ = "batches"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False)
    start_date = Column(DateTime, nullable=False)
    end_date = Column(DateTime, nullable=False)
    status = Column(String, default="active")  # active, completed, planned
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    
    # Relationships
    trainees = relationship("Trainee", back_populates="batch")
    assessments = relationship("Assessment", back_populates="batch")

class Trainee(Base):
    __tablename__ = "trainees"
    
    id = Column(Integer, primary_key=True, index=True)
    trainee_id = Column(String, unique=True, index=True, nullable=False)
    full_name = Column(String, nullable=False)
    email = Column(String, nullable=False)
    phone = Column(String)
    batch_id = Column(Integer, ForeignKey("batches.id"))
    onboarding_date = Column(DateTime)
    current_stage = Column(String, default="onboarding")  # onboarding, training, assessment, deployment
    is_deployment_ready = Column(Boolean, default=False)
    readiness_score = Column(Float, default=0.0)
    status = Column(String, default="active")  # active, dropped, graduated, on_hold
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    
    # Relationships
    batch = relationship("Batch", back_populates="trainees")
    attempts = relationship("Attempt", back_populates="trainee")
    competency_scores = relationship("CompetencyScore", back_populates="trainee")
    alerts = relationship("Alert", back_populates="trainee")
    ai_insights = relationship("AIInsight", back_populates="trainee")
    project_recommendations = relationship("ProjectRecommendation", back_populates="trainee")

class Assessment(Base):
    __tablename__ = "assessments"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False)
    batch_id = Column(Integer, ForeignKey("batches.id"))
    module = Column(String, nullable=False)
    max_score = Column(Float, default=100.0)
    passing_score = Column(Float, default=60.0)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    
    # Relationships
    batch = relationship("Batch", back_populates="assessments")
    attempts = relationship("Attempt", back_populates="assessment")

class Attempt(Base):
    __tablename__ = "attempts"
    
    id = Column(Integer, primary_key=True, index=True)
    trainee_id = Column(Integer, ForeignKey("trainees.id"))
    assessment_id = Column(Integer, ForeignKey("assessments.id"))
    score = Column(Float, nullable=False)
    attempt_number = Column(Integer, default=1)
    completed_at = Column(DateTime(timezone=True), server_default=func.now())
    
    # Relationships
    trainee = relationship("Trainee", back_populates="attempts")
    assessment = relationship("Assessment", back_populates="attempts")

class Competency(Base):
    __tablename__ = "competencies"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, unique=True, nullable=False)
    category = Column(String, nullable=False)  # technical, soft_skill, domain
    weight = Column(Float, default=1.0)

class CompetencyScore(Base):
    __tablename__ = "competency_scores"
    
    id = Column(Integer, primary_key=True, index=True)
    trainee_id = Column(Integer, ForeignKey("trainees.id"))
    competency_id = Column(Integer, ForeignKey("competencies.id"))
    score = Column(Float, nullable=False)
    assessed_at = Column(DateTime(timezone=True), server_default=func.now())
    
    # Relationships
    trainee = relationship("Trainee", back_populates="competency_scores")

class Alert(Base):
    __tablename__ = "alerts"
    
    id = Column(Integer, primary_key=True, index=True)
    trainee_id = Column(Integer, ForeignKey("trainees.id"))
    user_id = Column(Integer, ForeignKey("users.id"))
    alert_type = Column(String, nullable=False)  # dropout_risk, low_performance, attendance, etc.
    severity = Column(String, nullable=False)  # high, medium, low
    message = Column(Text, nullable=False)
    is_resolved = Column(Boolean, default=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    resolved_at = Column(DateTime(timezone=True))
    
    # Relationships
    trainee = relationship("Trainee", back_populates="alerts")
    user = relationship("User", back_populates="alerts")

class AIInsight(Base):
    __tablename__ = "ai_insights"
    
    id = Column(Integer, primary_key=True, index=True)
    trainee_id = Column(Integer, ForeignKey("trainees.id"))
    insight_type = Column(String, nullable=False)  # dropout_risk, performance, recommendation
    content = Column(JSON, nullable=False)
    cached_at = Column(DateTime(timezone=True), server_default=func.now())
    
    # Relationships
    trainee = relationship("Trainee", back_populates="ai_insights")

class ProjectRecommendation(Base):
    __tablename__ = "project_recommendations"
    
    id = Column(Integer, primary_key=True, index=True)
    trainee_id = Column(Integer, ForeignKey("trainees.id"))
    project_name = Column(String, nullable=False)
    match_score = Column(Float, nullable=False)
    justification = Column(Text, nullable=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    
    # Relationships
    trainee = relationship("Trainee", back_populates="project_recommendations")

class ExportHistory(Base):
    __tablename__ = "export_history"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    export_type = Column(String, nullable=False)  # pdf, excel
    data_type = Column(String, nullable=False)  # trainee_summary, batch_report, etc.
    file_path = Column(String)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

class AuditLog(Base):
    __tablename__ = "audit_logs"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    action = Column(String, nullable=False)
    resource = Column(String, nullable=False)
    details = Column(JSON)
    ip_address = Column(String)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    
    # Relationships
    user = relationship("User", back_populates="audit_logs")