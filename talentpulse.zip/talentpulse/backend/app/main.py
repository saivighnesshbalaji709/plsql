from fastapi import FastAPI, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import OAuth2PasswordBearer
from contextlib import asynccontextmanager
import logging

from .database import engine, Base
from .routes import auth, trainees, batches, assessments, insights, reports, users, exports
from .agents import DropoutPredictorAgent, CPMMatchingAgent, PerformanceInsightAgent

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup
    Base.metadata.create_all(bind=engine)
    logger.info("Database tables created")
    yield
    # Shutdown
    logger.info("Shutting down...")

app = FastAPI(
    title="TalentPulse API",
    description="AI-Driven Talent Management Platform",
    version="1.0.0",
    lifespan=lifespan
)

# CORS configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:4200"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers
app.include_router(auth.router, prefix="/api/auth", tags=["authentication"])
app.include_router(trainees.router, prefix="/api/trainees", tags=["trainees"])
app.include_router(batches.router, prefix="/api/batches", tags=["batches"])
app.include_router(assessments.router, prefix="/api/assessments", tags=["assessments"])
app.include_router(insights.router, prefix="/api/insights", tags=["insights"])
app.include_router(reports.router, prefix="/api/reports", tags=["reports"])
app.include_router(users.router, prefix="/api/users", tags=["users"])
app.include_router(exports.router, prefix="/api/exports", tags=["exports"])

@app.get("/")
async def root():
    return {"message": "TalentPulse API", "status": "running"}

@app.get("/health")
async def health_check():
    return {"status": "healthy"}