from pydantic import BaseModel, EmailStr
from datetime import datetime
from typing import Optional, List, Dict, Any

# User schemas
class UserBase(BaseModel):
    email: EmailStr
    username: str
    full_name: str
    role: str

class UserCreate(UserBase):
    password: str

class UserUpdate(BaseModel):
    full_name: Optional[str] = None
    email: Optional[EmailStr] = None
    is_active: Optional[bool] = None

class UserResponse(UserBase):
    id: int
    is_active: bool
    created_at: datetime
    
    class Config:
        from_attributes = True

class UserLogin(BaseModel):
    username: str
    password: str
    role: str

class Token(BaseModel):
    access_token: str
    token_type: str
    user: UserResponse

# Batch schemas
class BatchBase(BaseModel):
    name: str
    start_date: datetime
    end_date: datetime
    status: str = "active"

class BatchCreate(BatchBase):
    pass

class BatchResponse(BatchBase):
    id: int
    created_at: datetime
    trainee_count: Optional[int] = None
    
    class Config:
        from_attributes = True

# Trainee schemas
class TraineeBase(BaseModel):
    trainee_id: str
    full_name: str
    email: EmailStr
    phone: Optional[str] = None
    batch_id: int

class TraineeCreate(TraineeBase):
    pass

class TraineeResponse(TraineeBase):
    id: int
    current_stage: str
    is_deployment_ready: bool
    readiness_score: float
    status: str
    created_at: datetime
    batch_name: Optional[str] = None
    
    class Config:
        from_attributes = True

# Assessment schemas
class AssessmentBase(BaseModel):
    name: str
    batch_id: int
    module: str
    max_score: float = 100.0
    passing_score: float = 60.0

class AssessmentCreate(AssessmentBase):
    pass

class AssessmentResponse(AssessmentBase):
    id: int
    created_at: datetime
    
    class Config:
        from_attributes = True

# Attempt schemas
class AttemptCreate(BaseModel):
    trainee_id: int
    assessment_id: int
    score: float
    attempt_number: int = 1

class AttemptResponse(BaseModel):
    id: int
    trainee_id: int
    assessment_id: int
    score: float
    attempt_number: int
    completed_at: datetime
    assessment_name: Optional[str] = None
    
    class Config:
        from_attributes = True

# AI Insights schemas
class DropoutRiskResponse(BaseModel):
    risk_level: str  # High, Medium, Low
    risk_score: float
    reason: str
    contributing_factors: List[str]

class PerformanceInsightResponse(BaseModel):
    summary: str
    strengths: List[str]
    weaknesses: List[str]
    recommendations: List[str]
    overall_rating: str

class ProjectMatchResponse(BaseModel):
    project_name: str
    match_score: float
    justification: str
    alternative_projects: List[Dict[str, Any]]

# Analytics schemas
class DashboardKPIs(BaseModel):
    total_trainees: int
    completion_rate: float
    average_score: float
    risk_count: int
    top_performers: int
    deployment_ready_count: int
    active_batches: int

class BatchPerformance(BaseModel):
    batch_id: int
    batch_name: str
    average_score: float
    completion_rate: float
    deployment_rate: float
    risk_count: int

# Report schemas
class ExportRequest(BaseModel):
    export_type: str  # pdf, excel
    data_type: str  # trainee_summary, batch_report, risk_report, readiness_report, performance_report
    filters: Optional[Dict[str, Any]] = None