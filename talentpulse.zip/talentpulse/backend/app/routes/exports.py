from fastapi import APIRouter, Depends, HTTPException, Response
from sqlalchemy.orm import Session
from typing import Dict, Any
import pandas as pd
from io import BytesIO
from datetime import datetime

from .. import models, auth, schemas
from ..database import get_db
from ..services.export_service import ExportService

router = APIRouter()
export_service = ExportService()

@router.post("/excel/trainees")
async def export_trainees_to_excel(
    batch_id: int = None,
    current_user: models.User = Depends(auth.get_current_active_user),
    db: Session = Depends(get_db)
):
    """Export trainees data to Excel"""
    query = db.query(models.Trainee)
    if batch_id:
        query = query.filter(models.Trainee.batch_id == batch_id)
    
    trainees = query.all()
    
    data = []
    for trainee in trainees:
        # Get attempts
        attempts = db.query(models.Attempt).filter(models.Attempt.trainee_id == trainee.id).all()
        avg_score = sum(a.score for a in attempts) / len(attempts) if attempts else 0
        
        data.append({
            "Trainee ID": trainee.trainee_id,
            "Full Name": trainee.full_name,
            "Email": trainee.email,
            "Batch": trainee.batch.name if trainee.batch else "N/A",
            "Current Stage": trainee.current_stage,
            "Readiness Score": trainee.readiness_score,
            "Deployment Ready": "Yes" if trainee.is_deployment_ready else "No",
            "Average Score": round(avg_score, 2),
            "Status": trainee.status,
            "Onboarding Date": trainee.onboarding_date.strftime("%Y-%m-%d") if trainee.onboarding_date else "N/A"
        })
    
    df = pd.DataFrame(data)
    
    # Create Excel file
    output = BytesIO()
    with pd.ExcelWriter(output, engine='openpyxl') as writer:
        df.to_excel(writer, sheet_name="Trainees", index=False)
        
        # Auto-adjust columns
        worksheet = writer.sheets["Trainees"]
        for column in worksheet.columns:
            max_length = 0
            column_letter = column[0].column_letter
            for cell in column:
                try:
                    if len(str(cell.value)) > max_length:
                        max_length = len(str(cell.value))
                except:
                    pass
            adjusted_width = min(max_length + 2, 50)
            worksheet.column_dimensions[column_letter].width = adjusted_width
    
    # Log export
    export_log = models.ExportHistory(
        user_id=current_user.id,
        export_type="excel",
        data_type="trainee_export",
        file_path=f"exports/trainees_{datetime.now().timestamp()}.xlsx"
    )
    db.add(export_log)
    db.commit()
    
    return Response(
        content=output.getvalue(),
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f"attachment; filename=trainees_{datetime.now().strftime('%Y%m%d')}.xlsx"}
    )

@router.post("/excel/batches")
async def export_batches_to_excel(
    current_user: models.User = Depends(auth.get_current_active_user),
    db: Session = Depends(get_db)
):
    """Export batches performance to Excel"""
    batches = db.query(models.Batch).all()
    
    data = []
    for batch in batches:
        trainees = db.query(models.Trainee).filter(models.Trainee.batch_id == batch.id).all()
        attempts = db.query(models.Attempt).join(models.Trainee).filter(
            models.Trainee.batch_id == batch.id
        ).all()
        
        avg_score = sum(a.score for a in attempts) / len(attempts) if attempts else 0
        completion_rate = (sum(1 for t in trainees if t.current_stage == "deployment") / len(trainees)) * 100 if trainees else 0
        deployment_rate = (sum(1 for t in trainees if t.is_deployment_ready) / len(trainees)) * 100 if trainees else 0
        
        data.append({
            "Batch Name": batch.name,
            "Start Date": batch.start_date.strftime("%Y-%m-%d"),
            "End Date": batch.end_date.strftime("%Y-%m-%d"),
            "Total Trainees": len(trainees),
            "Average Score": round(avg_score, 2),
            "Completion Rate (%)": round(completion_rate, 2),
            "Deployment Rate (%)": round(deployment_rate, 2),
            "Status": batch.status
        })
    
    df = pd.DataFrame(data)
    
    output = BytesIO()
    with pd.ExcelWriter(output, engine='openpyxl') as writer:
        df.to_excel(writer, sheet_name="Batches", index=False)
    
    return Response(
        content=output.getvalue(),
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f"attachment; filename=batches_{datetime.now().strftime('%Y%m%d')}.xlsx"}
    )

@router.post("/pdf/performance/{trainee_id}")
async def export_performance_pdf(
    trainee_id: int,
    current_user: models.User = Depends(auth.get_current_active_user),
    db: Session = Depends(get_db)
):
    """Export individual trainee performance report as PDF"""
    trainee = db.query(models.Trainee).filter(models.Trainee.id == trainee_id).first()
    if not trainee:
        raise HTTPException(status_code=404, detail="Trainee not found")
    
    # Get trainee data
    attempts = db.query(models.Attempt).filter(models.Attempt.trainee_id == trainee_id).all()
    
    report_data = {
        "title": f"Performance Report - {trainee.full_name}",
        "trainee": {
            "name": trainee.full_name,
            "id": trainee.trainee_id,
            "batch": trainee.batch.name if trainee.batch else "N/A",
            "stage": trainee.current_stage,
            "readiness_score": trainee.readiness_score
        },
        "assessments": [
            {
                "name": attempt.assessment.name if attempt.assessment else "Unknown",
                "score": attempt.score,
                "attempt": attempt.attempt_number,
                "date": attempt.completed_at.strftime("%Y-%m-%d")
            }
            for attempt in attempts
        ]
    }
    
    pdf_content = export_service.to_pdf(report_data, "performance_report")
    
    return Response(
        content=pdf_content,
        media_type="application/pdf",
        headers={"Content-Disposition": f"attachment; filename=performance_{trainee.trainee_id}_{datetime.now().strftime('%Y%m%d')}.pdf"}
    )