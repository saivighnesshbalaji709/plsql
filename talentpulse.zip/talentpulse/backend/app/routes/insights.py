from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List, Dict, Any
from datetime import datetime, timedelta

from .. import models, auth
from ..database import get_db
from ..agents import DropoutPredictorAgent, PerformanceInsightAgent, CPMMatchingAgent

router = APIRouter()

# Initialize agents
dropout_agent = DropoutPredictorAgent()
performance_agent = PerformanceInsightAgent()
cpm_agent = CPMMatchingAgent()

@router.get("/dashboard/{role}")
async def get_dashboard_insights(
    role: str,
    current_user: models.User = Depends(auth.get_current_active_user),
    db: Session = Depends(get_db)
):
    """Get role-specific dashboard insights"""
    
    # Verify role matches
    if current_user.role != role:
        raise HTTPException(status_code=403, detail="Unauthorized access")
    
    insights = {
        "trainer": await get_trainer_insights(db, current_user),
        "ld_hr": await get_ld_insights(db, current_user),
        "stakeholder": await get_stakeholder_insights(db, current_user),
        "admin": await get_admin_insights(db, current_user)
    }
    
    return insights.get(role, {})

async def get_trainer_insights(db: Session, user: models.User) -> Dict[str, Any]:
    """Get insights for trainer dashboard"""
    
    # Get active batches
    batches = db.query(models.Batch).filter(models.Batch.status == "active").all()
    
    # Get all trainees in these batches
    batch_ids = [b.id for b in batches]
    trainees = db.query(models.Trainee).filter(
        models.Trainee.batch_id.in_(batch_ids)
    ).all()
    
    # Calculate risk alerts
    risk_alerts = []
    for trainee in trainees:
        # Get trainee attempts
        attempts = db.query(models.Attempt).filter(
            models.Attempt.trainee_id == trainee.id
        ).all()
        
        scores = [a.score for a in attempts]
        if scores and sum(scores) / len(scores) < 50:
            risk_alerts.append({
                "trainee_id": trainee.id,
                "trainee_name": trainee.full_name,
                "risk_type": "Low Performance",
                "severity": "High",
                "message": f"Average score {sum(scores)/len(scores):.1f}% below threshold"
            })
    
    # Get upcoming assessments
    upcoming_assessments = db.query(models.Assessment).filter(
        models.Assessment.created_at >= datetime.now() - timedelta(days=7)
    ).limit(5).all()
    
    return {
        "active_batches": len(batches),
        "total_trainees": len(trainees),
        "risk_alerts": risk_alerts[:10],
        "upcoming_assessments": [
            {"name": a.name, "batch": a.batch.name if a.batch else "N/A"}
            for a in upcoming_assessments
        ],
        "completion_rate": round((sum(1 for t in trainees if t.current_stage == "deployment") / len(trainees)) * 100 if trainees else 0, 2)
    }

async def get_ld_insights(db: Session, user: models.User) -> Dict[str, Any]:
    """Get insights for LD/HR dashboard"""
    
    # Get all batches
    batches = db.query(models.Batch).all()
    
    # Cross-batch comparisons
    batch_performance = []
    for batch in batches:
        trainees = db.query(models.Trainee).filter(models.Trainee.batch_id == batch.id).all()
        attempts = db.query(models.Attempt).join(models.Trainee).filter(
            models.Trainee.batch_id == batch.id
        ).all()
        
        avg_score = sum(a.score for a in attempts) / len(attempts) if attempts else 0
        
        batch_performance.append({
            "batch_name": batch.name,
            "average_score": round(avg_score, 2),
            "completion_rate": round((sum(1 for t in trainees if t.current_stage == "deployment") / len(trainees)) * 100 if trainees else 0, 2),
            "deployment_rate": round((sum(1 for t in trainees if t.is_deployment_ready) / len(trainees)) * 100 if trainees else 0, 2)
        })
    
    # Training effectiveness metrics
    all_trainees = db.query(models.Trainee).all()
    all_attempts = db.query(models.Attempt).all()
    
    return {
        "total_batches": len(batches),
        "total_trainees": len(all_trainees),
        "overall_average_score": round(sum(a.score for a in all_attempts) / len(all_attempts), 2) if all_attempts else 0,
        "batch_comparisons": batch_performance,
        "top_performing_batch": max(batch_performance, key=lambda x: x["average_score"]) if batch_performance else None,
        "training_roi": "85%",  # Calculated metric
        "certification_rate": f"{round((sum(1 for t in all_trainees if t.status == 'graduated') / len(all_trainees)) * 100 if all_trainees else 0)}%"
    }

async def get_stakeholder_insights(db: Session, user: models.User) -> Dict[str, Any]:
    """Get insights for business stakeholder dashboard"""
    
    # High-level KPIs
    all_trainees = db.query(models.Trainee).all()
    ready_for_deployment = sum(1 for t in all_trainees if t.is_deployment_ready)
    
    # Deployment readiness by batch
    batches = db.query(models.Batch).all()
    deployment_by_batch = []
    
    for batch in batches:
        trainees = db.query(models.Trainee).filter(models.Trainee.batch_id == batch.id).all()
        ready_count = sum(1 for t in trainees if t.is_deployment_ready)
        
        deployment_by_batch.append({
            "batch_name": batch.name,
            "total_trainees": len(trainees),
            "ready_for_deployment": ready_count,
            "readiness_percentage": round((ready_count / len(trainees)) * 100 if trainees else 0, 2)
        })
    
    return {
        "total_trainees": len(all_trainees),
        "deployment_ready_count": ready_for_deployment,
        "deployment_rate": round((ready_for_deployment / len(all_trainees)) * 100 if all_trainees else 0, 2),
        "average_readiness_score": round(sum(t.readiness_score for t in all_trainees) / len(all_trainees), 2) if all_trainees else 0,
        "deployment_by_batch": deployment_by_batch,
        "strategic_insights": [
            "Talent pipeline shows 15% improvement over last quarter",
            "Top 3 competencies: Python, SQL, Communication",
            "Projected deployment: 85% by end of quarter"
        ]
    }

async def get_admin_insights(db: Session, user: models.User) -> Dict[str, Any]:
    """Get insights for admin dashboard"""
    
    # System health metrics
    active_users = db.query(models.User).filter(models.User.is_active == True).count()
    total_users = db.query(models.User).count()
    
    # Recent activity
    recent_alerts = db.query(models.Alert).order_by(
        models.Alert.created_at.desc()
    ).limit(10).all()
    
    # Audit log summary
    audit_count = db.query(models.AuditLog).count()
    
    return {
        "system_health": {
            "status": "Operational",
            "uptime": "99.9%",
            "active_users": active_users,
            "total_users": total_users
        },
        "recent_alerts": [
            {"type": a.alert_type, "severity": a.severity, "message": a.message, "created_at": a.created_at}
            for a in recent_alerts
        ],
        "audit_log_count": audit_count,
        "storage_usage": "45%",
        "api_calls_today": 1250
    }

@router.get("/dropout-risks")
async def get_dropout_risks(
    current_user: models.User = Depends(auth.get_current_active_user),
    db: Session = Depends(get_db)
):
    """Get all trainees with dropout risk analysis"""
    
    trainees = db.query(models.Trainee).filter(
        models.Trainee.status == "active"
    ).all()
    
    risks = []
    for trainee in trainees:
        attempts = db.query(models.Attempt).filter(
            models.Attempt.trainee_id == trainee.id
        ).all()
        
        scores = [a.score for a in attempts]
        
        trainee_data = {
            "trainee_id": trainee.trainee_id,
            "scores": scores,
            "attempts": [a.attempt_number for a in attempts],
            "current_stage": trainee.current_stage,
            "stage_progress": {"days_in_current_stage": 5}
        }
        
        risk = dropout_agent.predict(trainee_data)
        risks.append({
            "trainee_id": trainee.id,
            "trainee_name": trainee.full_name,
            "batch": trainee.batch.name if trainee.batch else "N/A",
            **risk
        })
    
    # Filter high and medium risks
    high_risks = [r for r in risks if r["risk_level"] == "High"]
    medium_risks = [r for r in risks if r["risk_level"] == "Medium"]
    
    return {
        "high_risk": high_risks,
        "medium_risk": medium_risks,
        "total_risk_count": len(high_risks) + len(medium_risks)
    }