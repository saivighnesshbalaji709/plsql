from .auth import router as auth_router
from .trainees import router as trainees_router
from .batches import router as batches_router
from .assessments import router as assessments_router
from .insights import router as insights_router
from .reports import router as reports_router
from .users import router as users_router
from .exports import router as exports_router

__all__ = [
    'auth_router',
    'trainees_router', 
    'batches_router',
    'assessments_router',
    'insights_router',
    'reports_router',
    'users_router',
    'exports_router'
]