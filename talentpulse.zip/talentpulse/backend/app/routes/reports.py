from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import Dict, Any
import pandas as pd
from datetime import datetime

from .. import models, auth, schemas
from ..database import get_db
from ..services.export_service import ExportService

router = APIRouter()
export_service = ExportService()

@router.post("/generate")
async def generate_report(
    request: schemas.ExportRequest,
    current_user: models.User = Depends(auth.get_current_active_user),
    db: Session = Depends(get_db)
):
    """Generate report based on type and filters"""
    
    # Determine if user has access to requested data
    allowed_data_types = {
        "trainer": ["trainee_summary", "batch_report"],
        "ld_hr": ["trainee_summary", "batch_report", "risk_report", "performance_report"],
        "stakeholder": ["batch_report", "readiness_report"],
        "admin": ["trainee_summary", "batch_report", "risk_report", "readiness_report", "performance_report", "audit_report"]
    }
    
    if request.data_type not in allowed_data_types.get(current_user.role, []):
        raise HTTPException(status_code=403, detail="Not authorized to generate this report type")
    
    # Generate data based on type
    report_data = await _generate_report_data(request, current_user, db)
    
    # Create export record
    export_record = models.ExportHistory(
        user_id=current_user.id,
        export_type=request.export_type,
        data_type=request.data_type,
        file_path=f"exports/{request.data_type}_{datetime.now().timestamp()}.{request.export_type}"
    )
    db.add(export_record)
    db.commit()
    
    # Generate file
    if request.export_type == "excel":
        file_content = export_service.to_excel(report_data, request.data_type)
        media_type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        filename = f"{request.data_type}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
    else:  # pdf
        file_content = export_service.to_pdf(report_data, request.data_type)
        media_type = "application/pdf"
        filename = f"{request.data_type}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
    
    return {
        "filename": filename,
        "content": file_content,
        "media_type": media_type
    }

async def _generate_report_data(request: schemas.ExportRequest, current_user: models.User, db: Session) -> Dict[str, Any]:
    """Generate the actual report data"""
    
    if request.data_type == "trainee_summary":
        query = db.query(models.Trainee)
        if request.filters and request.filters.get("batch_id"):
            query = query.filter(models.Trainee.batch_id == request.filters["batch_id"])
        
        trainees = query.all()
        
        data = []
        for trainee in trainees:
            attempts = db.query(models.Attempt).filter(models.Attempt.trainee_id == trainee.id).all()
            avg_score = sum(a.score for a in attempts) / len(attempts) if attempts else 0
            
            data.append({
                "Trainee ID": trainee.trainee_id,
                "Name": trainee.full_name,
                "Email": trainee.email,
                "Batch": trainee.batch.name if trainee.batch else "N/A",
                "Current Stage": trainee.current_stage,
                "Readiness Score": trainee.readiness_score,
                "Average Score": round(avg_score, 2),
                "Deployment Ready": "Yes" if trainee.is_deployment_ready else "No",
                "Status": trainee.status
            })
        
        return {"data": data, "title": "Trainee Summary Report"}
    
    elif request.data_type == "batch_report":
        batches = db.query(models.Batch).all()
        
        data = []
        for batch in batches:
            trainees = db.query(models.Trainee).filter(models.Trainee.batch_id == batch.id).all()
            attempts = db.query(models.Attempt).join(models.Trainee).filter(
                models.Trainee.batch_id == batch.id
            ).all()
            
            avg_score = sum(a.score for a in attempts) / len(attempts) if attempts else 0
            completion_rate = (sum(1 for t in trainees if t.current_stage == "deployment") / len(trainees)) * 100 if trainees else 0
            deployment_rate = (sum(1 for t in trainees if t.is_deployment_ready) / len(trainees)) * 100 if trainees else 0
            
            data.append({
                "Batch Name": batch.name,
                "Start Date": batch.start_date.strftime("%Y-%m-%d"),
                "End Date": batch.end_date.strftime("%Y-%m-%d"),
                "Total Trainees": len(trainees),
                "Average Score": round(avg_score, 2),
                "Completion Rate (%)": round(completion_rate, 2),
                "Deployment Rate (%)": round(deployment_rate, 2),
                "Status": batch.status
            })
        
        return {"data": data, "title": "Batch Performance Report"}
    
    elif request.data_type == "risk_report":
        # Get dropout risks
        from ..agents import DropoutPredictorAgent
        agent = DropoutPredictorAgent()
        
        trainees = db.query(models.Trainee).filter(models.Trainee.status == "active").all()
        
        data = []
        for trainee in trainees:
            attempts = db.query(models.Attempt).filter(models.Attempt.trainee_id == trainee.id).all()
            scores = [a.score for a in attempts]
            
            trainee_data = {
                "trainee_id": trainee.trainee_id,
                "scores": scores,
                "attempts": [a.attempt_number for a in attempts],
                "current_stage": trainee.current_stage,
                "stage_progress": {"days_in_current_stage": 0}
            }
            
            risk = agent.predict(trainee_data)
            
            data.append({
                "Trainee Name": trainee.full_name,
                "Batch": trainee.batch.name if trainee.batch else "N/A",
                "Risk Level": risk["risk_level"],
                "Risk Score": round(risk["risk_score"] * 100, 2),
                "Reason": risk["reason"],
                "Contributing Factors": ", ".join(risk["contributing_factors"])
            })
        
        return {"data": data, "title": "Dropout Risk Analysis Report"}
    
    else:
        return {"data": [], "title": "Report"}