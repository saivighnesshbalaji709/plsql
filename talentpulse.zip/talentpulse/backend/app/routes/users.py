from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import List, Optional

from .. import schemas, models, auth
from ..database import get_db

router = APIRouter()

@router.get("/", response_model=List[schemas.UserResponse])
async def get_users(
    skip: int = 0,
    limit: int = 100,
    role: Optional[str] = None,
    current_user: models.User = Depends(auth.get_user_role_required(["admin"])),
    db: Session = Depends(get_db)
):
    """Get all users (admin only)"""
    query = db.query(models.User)
    
    if role:
        query = query.filter(models.User.role == role)
    
    users = query.offset(skip).limit(limit).all()
    return users

@router.get("/{user_id}", response_model=schemas.UserResponse)
async def get_user(
    user_id: int,
    current_user: models.User = Depends(auth.get_user_role_required(["admin"])),
    db: Session = Depends(get_db)
):
    """Get specific user (admin only)"""
    user = db.query(models.User).filter(models.User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    return user

@router.post("/", response_model=schemas.UserResponse)
async def create_user(
    user: schemas.UserCreate,
    current_user: models.User = Depends(auth.get_user_role_required(["admin"])),
    db: Session = Depends(get_db)
):
    """Create new user (admin only)"""
    # Check if user exists
    existing = db.query(models.User).filter(
        (models.User.username == user.username) | (models.User.email == user.email)
    ).first()
    
    if existing:
        raise HTTPException(status_code=400, detail="Username or email already exists")
    
    # Create user
    hashed_password = auth.get_password_hash(user.password)
    db_user = models.User(
        email=user.email,
        username=user.username,
        full_name=user.full_name,
        hashed_password=hashed_password,
        role=user.role
    )
    
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    
    # Log the action
    audit_log = models.AuditLog(
        user_id=current_user.id,
        action="CREATE_USER",
        resource="users",
        details={"user_id": db_user.id, "username": db_user.username}
    )
    db.add(audit_log)
    db.commit()
    
    return db_user

@router.put("/{user_id}", response_model=schemas.UserResponse)
async def update_user(
    user_id: int,
    user_update: schemas.UserUpdate,
    current_user: models.User = Depends(auth.get_user_role_required(["admin"])),
    db: Session = Depends(get_db)
):
    """Update user (admin only)"""
    user = db.query(models.User).filter(models.User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    update_data = user_update.model_dump(exclude_unset=True)
    for field, value in update_data.items():
        setattr(user, field, value)
    
    db.commit()
    db.refresh(user)
    
    # Log the action
    audit_log = models.AuditLog(
        user_id=current_user.id,
        action="UPDATE_USER",
        resource="users",
        details={"user_id": user_id, "changes": update_data}
    )
    db.add(audit_log)
    db.commit()
    
    return user

@router.delete("/{user_id}")
async def delete_user(
    user_id: int,
    current_user: models.User = Depends(auth.get_user_role_required(["admin"])),
    db: Session = Depends(get_db)
):
    """Delete user (admin only)"""
    user = db.query(models.User).filter(models.User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    if user.id == current_user.id:
        raise HTTPException(status_code=400, detail="Cannot delete yourself")
    
    db.delete(user)
    db.commit()
    
    # Log the action
    audit_log = models.AuditLog(
        user_id=current_user.id,
        action="DELETE_USER",
        resource="users",
        details={"user_id": user_id, "username": user.username}
    )
    db.add(audit_log)
    db.commit()
    
    return {"message": "User deleted successfully"}

@router.get("/audit-logs")
async def get_audit_logs(
    skip: int = 0,
    limit: int = 100,
    current_user: models.User = Depends(auth.get_user_role_required(["admin"])),
    db: Session = Depends(get_db)
):
    """Get audit logs (admin only)"""
    logs = db.query(models.AuditLog).order_by(
        models.AuditLog.created_at.desc()
    ).offset(skip).limit(limit).all()
    
    return logs