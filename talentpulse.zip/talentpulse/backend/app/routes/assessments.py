from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import List, Optional
from datetime import datetime

from .. import schemas, models, auth
from ..database import get_db

router = APIRouter()

@router.get("/", response_model=List[schemas.AssessmentResponse])
async def get_assessments(
    skip: int = 0,
    limit: int = 100,
    batch_id: Optional[int] = None,
    current_user: models.User = Depends(auth.get_current_active_user),
    db: Session = Depends(get_db)
):
    """Get all assessments"""
    query = db.query(models.Assessment)
    
    if batch_id:
        query = query.filter(models.Assessment.batch_id == batch_id)
    
    assessments = query.offset(skip).limit(limit).all()
    return assessments

@router.get("/{assessment_id}", response_model=schemas.AssessmentResponse)
async def get_assessment(
    assessment_id: int,
    current_user: models.User = Depends(auth.get_current_active_user),
    db: Session = Depends(get_db)
):
    """Get specific assessment"""
    assessment = db.query(models.Assessment).filter(models.Assessment.id == assessment_id).first()
    if not assessment:
        raise HTTPException(status_code=404, detail="Assessment not found")
    return assessment

@router.post("/", response_model=schemas.AssessmentResponse)
async def create_assessment(
    assessment: schemas.AssessmentCreate,
    current_user: models.User = Depends(auth.get_user_role_required(["admin", "trainer"])),
    db: Session = Depends(get_db)
):
    """Create new assessment"""
    db_assessment = models.Assessment(**assessment.model_dump())
    db.add(db_assessment)
    db.commit()
    db.refresh(db_assessment)
    return db_assessment

@router.post("/{assessment_id}/attempts", response_model=schemas.AttemptResponse)
async def submit_attempt(
    assessment_id: int,
    attempt: schemas.AttemptCreate,
    current_user: models.User = Depends(auth.get_current_active_user),
    db: Session = Depends(get_db)
):
    """Submit an assessment attempt"""
    # Verify assessment exists
    assessment = db.query(models.Assessment).filter(models.Assessment.id == assessment_id).first()
    if not assessment:
        raise HTTPException(status_code=404, detail="Assessment not found")
    
    # Create attempt
    db_attempt = models.Attempt(
        trainee_id=attempt.trainee_id,
        assessment_id=assessment_id,
        score=attempt.score,
        attempt_number=attempt.attempt_number
    )
    
    db.add(db_attempt)
    db.commit()
    db.refresh(db_attempt)
    
    # Update trainee readiness score
    trainee = db.query(models.Trainee).filter(models.Trainee.id == attempt.trainee_id).first()
    if trainee:
        # Calculate new average score
        all_attempts = db.query(models.Attempt).filter(models.Attempt.trainee_id == trainee.id).all()
        avg_score = sum(a.score for a in all_attempts) / len(all_attempts) if all_attempts else 0
        
        # Update readiness score
        trainee.readiness_score = avg_score
        trainee.is_deployment_ready = avg_score >= 70
        
        db.commit()
    
    return db_attempt

@router.get("/{assessment_id}/statistics")
async def get_assessment_statistics(
    assessment_id: int,
    current_user: models.User = Depends(auth.get_current_active_user),
    db: Session = Depends(get_db)
):
    """Get statistics for an assessment"""
    attempts = db.query(models.Attempt).filter(models.Attempt.assessment_id == assessment_id).all()
    
    if not attempts:
        return {
            "assessment_id": assessment_id,
            "total_attempts": 0,
            "average_score": 0,
            "passing_rate": 0,
            "highest_score": 0,
            "lowest_score": 0
        }
    
    scores = [a.score for a in attempts]
    
    return {
        "assessment_id": assessment_id,
        "total_attempts": len(attempts),
        "average_score": round(sum(scores) / len(scores), 2),
        "passing_rate": round((sum(1 for s in scores if s >= 60) / len(scores)) * 100, 2),
        "highest_score": max(scores),
        "lowest_score": min(scores)
    }