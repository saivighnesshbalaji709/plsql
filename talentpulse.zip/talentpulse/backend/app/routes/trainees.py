from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import List, Optional
from sqlalchemy import func, and_

from .. import schemas, models, auth
from ..database import get_db
from ..agents import DropoutPredictorAgent, PerformanceInsightAgent, CPMMatchingAgent

router = APIRouter()

# Initialize agents
dropout_agent = DropoutPredictorAgent()
performance_agent = PerformanceInsightAgent()
cpm_agent = CPMMatchingAgent()

@router.get("/", response_model=List[schemas.TraineeResponse])
async def get_trainees(
    skip: int = 0,
    limit: int = 100,
    batch_id: Optional[int] = None,
    status: Optional[str] = None,
    current_user: models.User = Depends(auth.get_current_active_user),
    db: Session = Depends(get_db)
):
    """Get all trainees with optional filters"""
    query = db.query(models.Trainee)
    
    if batch_id:
        query = query.filter(models.Trainee.batch_id == batch_id)
    if status:
        query = query.filter(models.Trainee.status == status)
    
    trainees = query.offset(skip).limit(limit).all()
    
    # Add batch names
    for trainee in trainees:
        if trainee.batch:
            trainee.batch_name = trainee.batch.name
    
    return trainees

@router.get("/{trainee_id}", response_model=schemas.TraineeResponse)
async def get_trainee(
    trainee_id: int,
    current_user: models.User = Depends(auth.get_current_active_user),
    db: Session = Depends(get_db)
):
    """Get specific trainee details"""
    trainee = db.query(models.Trainee).filter(models.Trainee.id == trainee_id).first()
    if not trainee:
        raise HTTPException(status_code=404, detail="Trainee not found")
    
    if trainee.batch:
        trainee.batch_name = trainee.batch.name
    
    return trainee

@router.post("/", response_model=schemas.TraineeResponse)
async def create_trainee(
    trainee: schemas.TraineeCreate,
    current_user: models.User = Depends(auth.get_user_role_required(["admin", "trainer"])),
    db: Session = Depends(get_db)
):
    """Create new trainee"""
    # Check if trainee ID exists
    existing = db.query(models.Trainee).filter(
        models.Trainee.trainee_id == trainee.trainee_id
    ).first()
    
    if existing:
        raise HTTPException(status_code=400, detail="Trainee ID already exists")
    
    db_trainee = models.Trainee(**trainee.model_dump())
    db.add(db_trainee)
    db.commit()
    db.refresh(db_trainee)
    
    return db_trainee

@router.get("/{trainee_id}/ai-insights")
async def get_trainee_ai_insights(
    trainee_id: int,
    current_user: models.User = Depends(auth.get_current_active_user),
    db: Session = Depends(get_db)
):
    """Get AI-generated insights for a trainee"""
    trainee = db.query(models.Trainee).filter(models.Trainee.id == trainee_id).first()
    if not trainee:
        raise HTTPException(status_code=404, detail="Trainee not found")
    
    # Get trainee data for AI analysis
    attempts = db.query(models.Attempt).filter(
        models.Attempt.trainee_id == trainee_id
    ).all()
    
    scores = [a.score for a in attempts]
    assessment_names = []
    for attempt in attempts:
        if attempt.assessment:
            assessment_names.append(attempt.assessment.name)
    
    # Get competency scores
    comp_scores = db.query(models.CompetencyScore).filter(
        models.CompetencyScore.trainee_id == trainee_id
    ).all()
    
    competencies = {}
    for cs in comp_scores:
        if cs.competency:
            competencies[cs.competency.name] = cs.score
    
    trainee_data = {
        "trainee_id": trainee.trainee_id,
        "scores": scores,
        "assessment_names": assessment_names,
        "competency_scores": competencies,
        "average_score": sum(scores) / len(scores) if scores else 0,
        "current_stage": trainee.current_stage,
        "stage_progress": {"days_in_current_stage": 5}  # Calculate from actual data
    }
    
    # Get AI insights
    dropout_risk = dropout_agent.predict(trainee_data)
    performance = performance_agent.analyze(trainee_data)
    project_match = cpm_agent.match(trainee_data)
    
    return {
        "dropout_risk": dropout_risk,
        "performance_insights": performance,
        "project_recommendation": project_match
    }

@router.post("/{trainee_id}/override-risk")
async def override_risk(
    trainee_id: int,
    risk_level: str,
    current_user: models.User = Depends(auth.get_user_role_required(["admin", "trainer"])),
    db: Session = Depends(get_db)
):
    """Manually override AI risk classification"""
    # Create alert with manual override
    alert = models.Alert(
        trainee_id=trainee_id,
        user_id=current_user.id,
        alert_type="manual_override",
        severity=risk_level,
        message=f"Risk level manually overridden to {risk_level} by {current_user.full_name}"
    )
    
    db.add(alert)
    db.commit()
    
    return {"message": "Risk level updated", "risk_level": risk_level}