from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import List, Optional
from sqlalchemy import func, and_

from .. import schemas, models, auth
from ..database import get_db

router = APIRouter()

@router.get("/", response_model=List[schemas.BatchResponse])
async def get_batches(
    skip: int = 0,
    limit: int = 100,
    status: Optional[str] = None,
    current_user: models.User = Depends(auth.get_current_active_user),
    db: Session = Depends(get_db)
):
    """Get all batches"""
    query = db.query(models.Batch)
    
    if status:
        query = query.filter(models.Batch.status == status)
    
    batches = query.offset(skip).limit(limit).all()
    
    # Add trainee count
    for batch in batches:
        batch.trainee_count = db.query(models.Trainee).filter(
            models.Trainee.batch_id == batch.id
        ).count()
    
    return batches

@router.get("/{batch_id}", response_model=schemas.BatchResponse)
async def get_batch(
    batch_id: int,
    current_user: models.User = Depends(auth.get_current_active_user),
    db: Session = Depends(get_db)
):
    """Get specific batch details"""
    batch = db.query(models.Batch).filter(models.Batch.id == batch_id).first()
    if not batch:
        raise HTTPException(status_code=404, detail="Batch not found")
    
    batch.trainee_count = db.query(models.Trainee).filter(
        models.Trainee.batch_id == batch_id
    ).count()
    
    return batch

@router.get("/{batch_id}/performance")
async def get_batch_performance(
    batch_id: int,
    current_user: models.User = Depends(auth.get_current_active_user),
    db: Session = Depends(get_db)
):
    """Get batch performance analytics"""
    batch = db.query(models.Batch).filter(models.Batch.id == batch_id).first()
    if not batch:
        raise HTTPException(status_code=404, detail="Batch not found")
    
    trainees = db.query(models.Trainee).filter(models.Trainee.batch_id == batch_id).all()
    
    # Calculate metrics
    total_trainees = len(trainees)
    if total_trainees == 0:
        return {
            "batch_id": batch_id,
            "batch_name": batch.name,
            "average_score": 0,
            "completion_rate": 0,
            "deployment_rate": 0,
            "risk_count": 0,
            "top_performers": [],
            "heatmap_data": []
        }
    
    # Get all attempts for this batch
    trainee_ids = [t.id for t in trainees]
    attempts = db.query(models.Attempt).filter(
        models.Attempt.trainee_id.in_(trainee_ids)
    ).all()
    
    # Calculate average scores per trainee
    trainee_scores = {}
    for trainee in trainees:
        trainee_attempts = [a for a in attempts if a.trainee_id == trainee.id]
        if trainee_attempts:
            avg_score = sum(a.score for a in trainee_attempts) / len(trainee_attempts)
        else:
            avg_score = 0
        trainee_scores[trainee.id] = avg_score
    
    avg_batch_score = sum(trainee_scores.values()) / total_trainees if total_trainees > 0 else 0
    
    # Calculate deployment readiness
    deployment_ready = sum(1 for t in trainees if t.is_deployment_ready)
    deployment_rate = (deployment_ready / total_trainees) * 100
    
    # Calculate risk count (using AI or simple rule)
    risk_count = sum(1 for t in trainees if t.readiness_score < 50)
    
    # Get top performers (top 20%)
    sorted_trainees = sorted(trainees, key=lambda x: trainee_scores.get(x.id, 0), reverse=True)
    top_count = max(1, int(total_trainees * 0.2))
    top_performers = [
        {
            "id": t.id,
            "name": t.full_name,
            "score": trainee_scores.get(t.id, 0)
        }
        for t in sorted_trainees[:top_count]
    ]
    
    # Generate heatmap data (attempts by assessment)
    assessments = db.query(models.Assessment).filter(models.Assessment.batch_id == batch_id).all()
    heatmap_data = []
    
    for assessment in assessments:
        assessment_attempts = [a for a in attempts if a.assessment_id == assessment.id]
        scores = [a.score for a in assessment_attempts]
        heatmap_data.append({
            "assessment": assessment.name,
            "average_score": sum(scores) / len(scores) if scores else 0,
            "attempt_count": len(assessment_attempts),
            "passing_rate": sum(1 for s in scores if s >= assessment.passing_score) / len(scores) * 100 if scores else 0
        })
    
    return {
        "batch_id": batch_id,
        "batch_name": batch.name,
        "average_score": round(avg_batch_score, 2),
        "completion_rate": round((sum(1 for t in trainees if t.current_stage == "deployment") / total_trainees) * 100, 2),
        "deployment_rate": round(deployment_rate, 2),
        "risk_count": risk_count,
        "top_performers": top_performers,
        "heatmap_data": heatmap_data
    }

@router.post("/", response_model=schemas.BatchResponse)
async def create_batch(
    batch: schemas.BatchCreate,
    current_user: models.User = Depends(auth.get_user_role_required(["admin", "trainer"])),
    db: Session = Depends(get_db)
):
    """Create new batch"""
    db_batch = models.Batch(**batch.model_dump())
    db.add(db_batch)
    db.commit()
    db.refresh(db_batch)
    
    return db_batch