from typing import Dict, Any, List
import numpy as np

class PerformanceInsightAgent:
    """
    Performance Insight Agent for generating actionable feedback
    """
    
    def __init__(self):
        self.cache = {}
    
    def analyze(self, trainee_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Generate comprehensive performance insights
        """
        cache_key = f"{trainee_data.get('trainee_id')}_{len(trainee_data.get('scores', []))}"
        
        if cache_key in self.cache:
            return self.cache[cache_key]
        
        scores = trainee_data.get('scores', [])
        assessment_names = trainee_data.get('assessment_names', [])
        competency_scores = trainee_data.get('competency_scores', {})
        
        # Calculate strengths and weaknesses
        strengths = []
        weaknesses = []
        
        # Analyze assessment performance
        if scores and assessment_names:
            score_zip = list(zip(assessment_names, scores))
            score_zip.sort(key=lambda x: x[1], reverse=True)
            
            # Top 2 as strengths
            for name, score in score_zip[:2]:
                if score >= 75:
                    strengths.append(f"Excellent performance in {name}")
                elif score >= 60:
                    strengths.append(f"Good performance in {name}")
            
            # Bottom 2 as weaknesses
            for name, score in score_zip[-2:]:
                if score < 60:
                    weaknesses.append(f"Needs improvement in {name}")
        
        # Analyze competencies
        if competency_scores:
            for comp, score in competency_scores.items():
                if score >= 80:
                    strengths.append(f"Strong {comp} competency")
                elif score < 50:
                    weaknesses.append(f"Developing {comp} competency")
        
        # Generate recommendations
        recommendations = self._generate_recommendations(strengths, weaknesses, scores)
        
        # Calculate overall rating
        avg_score = np.mean(scores) if scores else 0
        if avg_score >= 85:
            overall_rating = "Exceptional"
            summary = "Outstanding performance across all metrics. Ready for advanced challenges."
        elif avg_score >= 70:
            overall_rating = "Good"
            summary = "Solid performance with consistent achievement of learning objectives."
        elif avg_score >= 55:
            overall_rating = "Satisfactory"
            summary = "Meeting basic requirements but has room for improvement in key areas."
        else:
            overall_rating = "Needs Attention"
            summary = "Below expected performance levels. Requires targeted intervention and support."
        
        result = {
            "summary": summary,
            "strengths": strengths[:3],
            "weaknesses": weaknesses[:3],
            "recommendations": recommendations[:4],
            "overall_rating": overall_rating
        }
        
        self.cache[cache_key] = result
        return result
    
    def _generate_recommendations(self, strengths: List[str], weaknesses: List[str], scores: List[float]) -> List[str]:
        """Generate actionable recommendations"""
        recommendations = []
        
        if weaknesses:
            for weakness in weaknesses[:2]:
                recommendations.append(f"Focus on {weakness} through targeted practice and mentoring")
        
        if scores and min(scores) < 50:
            recommendations.append("Schedule one-on-one coaching sessions for challenging topics")
        
        if len(recommendations) < 3:
            recommendations.append("Continue building on existing strengths while addressing development areas")
            recommendations.append("Participate in peer learning sessions to reinforce understanding")
        
        return recommendations
    
    def clear_cache(self):
        self.cache.clear()