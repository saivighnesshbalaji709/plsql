from typing import Dict, Any, List
import numpy as np
from difflib import SequenceMatcher

class CPMMatchingAgent:
    """
    CPM (Career Path Matching) Agent for project recommendations
    """
    
    def __init__(self):
        self.project_database = {
            "AI/ML Engineer": {
                "required_skills": ["python", "machine learning", "deep learning", "tensorflow", "pytorch"],
                "competencies": ["technical", "problem_solving"],
                "min_score": 75
            },
            "Full Stack Developer": {
                "required_skills": ["javascript", "react", "node.js", "python", "sql"],
                "competencies": ["technical", "problem_solving"],
                "min_score": 70
            },
            "Data Analyst": {
                "required_skills": ["sql", "python", "pandas", "visualization", "statistics"],
                "competencies": ["technical", "analytical"],
                "min_score": 65
            },
            "Cloud Engineer": {
                "required_skills": ["aws", "docker", "kubernetes", "linux", "terraform"],
                "competencies": ["technical", "problem_solving"],
                "min_score": 70
            },
            "DevOps Specialist": {
                "required_skills": ["ci/cd", "jenkins", "git", "docker", "monitoring"],
                "competencies": ["technical", "automation"],
                "min_score": 70
            },
            "Business Analyst": {
                "required_skills": ["requirements", "agile", "communication", "documentation"],
                "competencies": ["soft_skill", "analytical"],
                "min_score": 60
            }
        }
        
        self.cache = {}
    
    def match(self, trainee_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Match trainee with best project based on skills, scores, and competencies
        """
        cache_key = f"{trainee_data.get('trainee_id')}"
        
        if cache_key in self.cache:
            return self.cache[cache_key]
        
        # Extract trainee profile
        skills = trainee_data.get('skills', [])
        competency_scores = trainee_data.get('competency_scores', {})
        average_score = trainee_data.get('average_score', 0)
        
        # Calculate match scores for each project
        matches = []
        
        for project_name, requirements in self.project_database.items():
            match_score = self._calculate_match_score(
                skills, 
                competency_scores, 
                average_score, 
                requirements
            )
            
            matches.append({
                "project_name": project_name,
                "match_score": match_score,
                "justification": self._generate_justification(project_name, requirements, match_score)
            })
        
        # Sort by match score and get top 3
        matches.sort(key=lambda x: x['match_score'], reverse=True)
        
        result = {
            "project_name": matches[0]['project_name'],
            "match_score": matches[0]['match_score'],
            "justification": matches[0]['justification'],
            "alternative_projects": matches[1:4]
        }
        
        self.cache[cache_key] = result
        return result
    
    def _calculate_match_score(self, skills: List[str], competencies: Dict[str, float], 
                               avg_score: float, requirements: Dict) -> float:
        """Calculate match score between 0 and 1"""
        score = 0
        
        # Skill match (40%)
        if skills and requirements['required_skills']:
            skill_matches = sum(1 for s in skills if s.lower() in [r.lower() for r in requirements['required_skills']])
            skill_ratio = skill_matches / len(requirements['required_skills'])
            score += skill_ratio * 0.4
        
        # Competency match (30%)
        comp_score = 0
        for comp in requirements['competencies']:
            if comp in competencies:
                comp_score += competencies[comp] / 100
        comp_avg = comp_score / len(requirements['competencies']) if requirements['competencies'] else 0
        score += comp_avg * 0.3
        
        # Overall performance (30%)
        score += (avg_score / 100) * 0.3
        
        return min(round(score * 100, 1), 100.0)
    
    def _generate_justification(self, project_name: str, requirements: Dict, match_score: float) -> str:
        """Generate human-readable justification"""
        if match_score >= 80:
            return f"Excellent fit for {project_name} role. Strong alignment with required skills and competencies."
        elif match_score >= 65:
            return f"Good match for {project_name} position. Some additional skill development recommended."
        else:
            return f"Potential fit for {project_name} with focused training on key skill areas."
    
    def clear_cache(self):
        self.cache.clear()