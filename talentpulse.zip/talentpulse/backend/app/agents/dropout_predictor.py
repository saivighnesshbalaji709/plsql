import numpy as np
from typing import Dict, Any, List
from datetime import datetime, timedelta
import logging

logger = logging.getLogger(__name__)

class DropoutPredictorAgent:
    """
    AI Agent for predicting dropout risk based on:
    - Assessment scores
    - Attempt counts
    - Stage gaps/delays
    - Attendance patterns
    """
    
    def __init__(self):
        # Cache for predictions
        self.cache = {}
        
    def predict(self, trainee_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Predict dropout risk using rule-based logic with AI enhancement
        """
        cache_key = f"{trainee_data.get('trainee_id')}_{trainee_data.get('last_updated')}"
        
        # Check cache
        if cache_key in self.cache:
            return self.cache[cache_key]
        
        # Extract features
        scores = trainee_data.get('scores', [])
        attempts = trainee_data.get('attempts', [])
        stage_progress = trainee_data.get('stage_progress', {})
        
        # Calculate risk factors
        risk_score = 0
        contributing_factors = []
        
        # Factor 1: Low scores (weight: 0.4)
        if scores:
            avg_score = np.mean(scores)
            if avg_score < 50:
                risk_score += 0.4
                contributing_factors.append("Consistently low assessment scores")
            elif avg_score < 65:
                risk_score += 0.2
                contributing_factors.append("Below average assessment performance")
        
        # Factor 2: Multiple attempts (weight: 0.3)
        if attempts:
            high_attempts = sum(1 for a in attempts if a > 2)
            if high_attempts > 2:
                risk_score += 0.3
                contributing_factors.append("Multiple retakes required for assessments")
            elif high_attempts > 0:
                risk_score += 0.15
        
        # Factor 3: Stage delays (weight: 0.3)
        current_stage = trainee_data.get('current_stage', 'onboarding')
        expected_duration = {
            'onboarding': 7,
            'training': 30,
            'assessment': 14,
            'deployment': 7
        }
        
        days_in_stage = stage_progress.get('days_in_current_stage', 0)
        expected = expected_duration.get(current_stage, 14)
        
        if days_in_stage > expected * 1.5:
            risk_score += 0.3
            contributing_factors.append(f"Delayed progress in {current_stage} stage")
        elif days_in_stage > expected:
            risk_score += 0.15
        
        # Determine risk level
        if risk_score >= 0.7:
            risk_level = "High"
            risk_score_value = risk_score
            reason = "Critical risk indicators detected. Immediate intervention recommended."
        elif risk_score >= 0.4:
            risk_level = "Medium"
            risk_score_value = risk_score
            reason = "Moderate risk factors identified. Monitor closely and provide support."
        else:
            risk_level = "Low"
            risk_score_value = risk_score
            reason = "Trainee is on track with minimal risk factors."
        
        result = {
            "risk_level": risk_level,
            "risk_score": risk_score_value,
            "reason": reason,
            "contributing_factors": contributing_factors
        }
        
        # Cache result
        self.cache[cache_key] = result
        return result
    
    def clear_cache(self):
        """Clear prediction cache"""
        self.cache.clear()