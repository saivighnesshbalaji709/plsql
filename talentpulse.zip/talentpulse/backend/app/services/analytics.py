from sqlalchemy.orm import Session
from sqlalchemy import func, and_
from typing import Dict, Any, List
from datetime import datetime, timedelta

from .. import models

class AnalyticsService:
    
    def __init__(self, db: Session):
        self.db = db
    
    def get_dashboard_kpis(self, role: str, user_id: int = None) -> Dict[str, Any]:
        """Get role-specific KPIs"""
        
        if role == "trainer":
            return self._get_trainer_kpis(user_id)
        elif role == "ld_hr":
            return self._get_ld_kpis()
        elif role == "stakeholder":
            return self._get_stakeholder_kpis()
        elif role == "admin":
            return self._get_admin_kpis()
        
        return {}
    
    def _get_trainer_kpis(self, user_id: int = None) -> Dict[str, Any]:
        """Get trainer dashboard KPIs"""
        
        # Get active batches
        active_batches = self.db.query(models.Batch).filter(
            models.Batch.status == "active"
        ).count()
        
        # Get total active trainees
        active_trainees = self.db.query(models.Trainee).filter(
            models.Trainee.status == "active"
        ).count()
        
        # Calculate average score
        all_attempts = self.db.query(models.Attempt).all()
        avg_score = sum(a.score for a in all_attempts) / len(all_attempts) if all_attempts else 0
        
        # Count high-risk trainees
        high_risk = self.db.query(models.Alert).filter(
            models.Alert.alert_type == "dropout_risk",
            models.Alert.severity == "high",
            models.Alert.is_resolved == False
        ).count()
        
        # Top performers (trainees with readiness_score > 80)
        top_performers = self.db.query(models.Trainee).filter(
            models.Trainee.readiness_score >= 80,
            models.Trainee.status == "active"
        ).count()
        
        # Deployment ready
        deployment_ready = self.db.query(models.Trainee).filter(
            models.Trainee.is_deployment_ready == True,
            models.Trainee.status == "active"
        ).count()
        
        return {
            "active_batches": active_batches,
            "active_trainees": active_trainees,
            "average_score": round(avg_score, 2),
            "high_risk_count": high_risk,
            "top_performers": top_performers,
            "deployment_ready": deployment_ready,
            "completion_rate": round((deployment_ready / active_trainees * 100) if active_trainees > 0 else 0, 2)
        }
    
    def _get_ld_kpis(self) -> Dict[str, Any]:
        """Get LD/HR dashboard KPIs"""
        
        total_trainees = self.db.query(models.Trainee).count()
        total_batches = self.db.query(models.Batch).count()
        
        all_attempts = self.db.query(models.Attempt).all()
        overall_score = sum(a.score for a in all_attempts) / len(all_attempts) if all_attempts else 0
        
        graduated = self.db.query(models.Trainee).filter(
            models.Trainee.status == "graduated"
        ).count()
        
        return {
            "total_trainees": total_trainees,
            "total_batches": total_batches,
            "overall_average": round(overall_score, 2),
            "graduation_rate": round((graduated / total_trainees * 100) if total_trainees > 0 else 0, 2)
        }
    
    def _get_stakeholder_kpis(self) -> Dict[str, Any]:
        """Get stakeholder dashboard KPIs"""
        
        ready_for_deployment = self.db.query(models.Trainee).filter(
            models.Trainee.is_deployment_ready == True
        ).count()
        
        total_trainees = self.db.query(models.Trainee).count()
        
        return {
            "deployment_readiness": round((ready_for_deployment / total_trainees * 100) if total_trainees > 0 else 0, 2),
            "ready_count": ready_for_deployment,
            "total_talent_pool": total_trainees
        }
    
    def _get_admin_kpis(self) -> Dict[str, Any]:
        """Get admin dashboard KPIs"""
        
        active_users = self.db.query(models.User).filter(
            models.User.is_active == True
        ).count()
        
        total_users = self.db.query(models.User).count()
        
        alerts_30d = self.db.query(models.Alert).filter(
            models.Alert.created_at >= datetime.now() - timedelta(days=30)
        ).count()
        
        return {
            "active_users": active_users,
            "total_users": total_users,
            "alerts_last_30_days": alerts_30d,
            "system_uptime": "99.9%"
        }
    
    def get_batch_performance_trend(self, batch_id: int) -> List[Dict]:
        """Get performance trend for a batch"""
        
        # Get all attempts in the batch
        attempts = self.db.query(models.Attempt).join(models.Trainee).filter(
            models.Trainee.batch_id == batch_id
        ).order_by(models.Attempt.completed_at).all()
        
        # Group by week
        weekly_data = {}
        for attempt in attempts:
            week = attempt.completed_at.strftime("%Y-W%W")
            if week not in weekly_data:
                weekly_data[week] = []
            weekly_data[week].append(attempt.score)
        
        trend = [
            {
                "week": week,
                "average_score": round(sum(scores) / len(scores), 2),
                "attempts_count": len(scores)
            }
            for week, scores in weekly_data.items()
        ]
        
        return trend