import pandas as pd
from io import BytesIO
from typing import List, Dict, Any, Tuple
from datetime import datetime

class ExcelProcessor:
    
    @staticmethod
    def validate_trainee_upload(file_content: bytes) -> Tuple[List[Dict], List[str]]:
        """Validate uploaded trainee Excel file"""
        
        try:
            df = pd.read_excel(BytesIO(file_content))
        except Exception as e:
            return [], [f"Error reading file: {str(e)}"]
        
        required_columns = ['trainee_id', 'full_name', 'email', 'batch_name']
        errors = []
        
        # Check required columns
        for col in required_columns:
            if col not in df.columns:
                errors.append(f"Missing required column: {col}")
        
        if errors:
            return [], errors
        
        # Validate data
        validated_data = []
        for idx, row in df.iterrows():
            row_errors = []
            
            # Check required fields
            if pd.isna(row.get('trainee_id')):
                row_errors.append("trainee_id is required")
            if pd.isna(row.get('full_name')):
                row_errors.append("full_name is required")
            if pd.isna(row.get('email')):
                row_errors.append("email is required")
            elif '@' not in str(row.get('email')):
                row_errors.append("invalid email format")
            
            if row_errors:
                errors.append(f"Row {idx + 2}: {', '.join(row_errors)}")
            else:
                validated_data.append({
                    'trainee_id': str(row['trainee_id']),
                    'full_name': str(row['full_name']),
                    'email': str(row['email']),
                    'batch_name': str(row['batch_name']),
                    'phone': str(row.get('phone', '')),
                    'onboarding_date': row.get('onboarding_date', datetime.now())
                })
        
        return validated_data, errors
    
    @staticmethod
    def generate_template() -> bytes:
        """Generate Excel template for trainee upload"""
        
        template_data = {
            'trainee_id': ['T001', 'T002'],
            'full_name': ['John Doe', 'Jane Smith'],
            'email': ['john@example.com', 'jane@example.com'],
            'batch_name': ['Batch 2024', 'Batch 2024'],
            'phone': ['1234567890', '0987654321'],
            'onboarding_date': [datetime.now(), datetime.now()]
        }
        
        df = pd.DataFrame(template_data)
        
        output = BytesIO()
        with pd.ExcelWriter(output, engine='openpyxl') as writer:
            df.to_excel(writer, sheet_name='Trainees', index=False)
            
            # Add instructions sheet
            instructions = pd.DataFrame({
                'Instruction': [
                    'trainee_id: Unique identifier for each trainee (Required)',
                    'full_name: Full name of the trainee (Required)',
                    'email: Valid email address (Required)',
                    'batch_name: Name of the batch (Required)',
                    'phone: Contact number (Optional)',
                    'onboarding_date: Date of joining (Optional, default is today)'
                ]
            })
            instructions.to_excel(writer, sheet_name='Instructions', index=False)
        
        return output.getvalue()
    
    @staticmethod
    def process_scores_upload(file_content: bytes) -> Tuple[List[Dict], List[str]]:
        """Process assessment scores upload"""
        
        try:
            df = pd.read_excel(BytesIO(file_content))
        except Exception as e:
            return [], [f"Error reading file: {str(e)}"]
        
        required_columns = ['trainee_id', 'assessment_name', 'score']
        errors = []
        
        for col in required_columns:
            if col not in df.columns:
                errors.append(f"Missing required column: {col}")
        
        if errors:
            return [], errors
        
        validated_data = []
        for idx, row in df.iterrows():
            try:
                score = float(row['score'])
                if score < 0 or score > 100:
                    errors.append(f"Row {idx + 2}: Score must be between 0 and 100")
                    continue
                
                validated_data.append({
                    'trainee_id': str(row['trainee_id']),
                    'assessment_name': str(row['assessment_name']),
                    'score': score,
                    'attempt_number': int(row.get('attempt_number', 1))
                })
            except ValueError:
                errors.append(f"Row {idx + 2}: Invalid score value")
        
        return validated_data, errors