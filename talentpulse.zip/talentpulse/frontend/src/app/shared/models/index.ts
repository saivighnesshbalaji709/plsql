export interface User {
  id: number;
  username: string;
  email: string;
  full_name: string;
  role: string;
  is_active: boolean;
  created_at: string;
}

export interface Batch {
  id: number;
  name: string;
  start_date: string;
  end_date: string;
  status: string;
  trainee_count?: number;
}

export interface Trainee {
  id: number;
  trainee_id: string;
  full_name: string;
  email: string;
  phone?: string;
  batch_id: number;
  batch_name?: string;
  current_stage: string;
  is_deployment_ready: boolean;
  readiness_score: number;
  status: string;
}

export interface Assessment {
  id: number;
  name: string;
  batch_id: number;
  module: string;
  max_score: number;
  passing_score: number;
}

export interface Attempt {
  id: number;
  trainee_id: number;
  assessment_id: number;
  score: number;
  attempt_number: number;
  completed_at: string;
  assessment_name?: string;
}

export interface DropoutRisk {
  risk_level: string;
  risk_score: number;
  reason: string;
  contributing_factors: string[];
}

export interface PerformanceInsight {
  summary: string;
  strengths: string[];
  weaknesses: string[];
  recommendations: string[];
  overall_rating: string;
}

export interface ProjectMatch {
  project_name: string;
  match_score: number;
  justification: string;
  alternative_projects: any[];
}

export interface DashboardKPI {
  total_trainees?: number;
  completion_rate?: number;
  average_score?: number;
  risk_count?: number;
  top_performers?: number;
  deployment_ready_count?: number;
  active_batches?: number;
}