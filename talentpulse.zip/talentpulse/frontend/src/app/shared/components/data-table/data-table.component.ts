import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { PageEvent } from '@angular/material/paginator';
import { Sort } from '@angular/material/sort';

@Component({
  selector: 'app-data-table',
  template: `
    <div class="table-container">
      <div class="table-toolbar" *ngIf="showToolbar">
        <div class="search-box">
          <mat-icon>search</mat-icon>
          <input type="text" placeholder="Search..." (input)="applyFilter($event)">
        </div>
        <div class="actions">
          <ng-content select="[actions]"></ng-content>
        </div>
      </div>
      
      <div class="mat-elevation-z0">
        <table mat-table [dataSource]="dataSource" matSort (matSortChange)="sortData($event)">
          <ng-container *ngFor="let column of columns" [matColumnDef]="column.key">
            <th mat-header-cell *matHeaderCellDef mat-sort-header [disabled]="!column.sortable">
              {{ column.label }}
            </th>
            <td mat-cell *matCellDef="let row">
              <ng-container *ngIf="column.template; else defaultCell">
                <ng-container *ngTemplateOutlet="column.template; context: { $implicit: row }"></ng-container>
              </ng-container>
              <ng-template #defaultCell>
                {{ row[column.key] }}
              </ng-template>
            </td>
          </ng-container>
          
          <tr mat-header-row *matHeaderRowDef="displayedColumns"></tr>
          <tr mat-row *matRowDef="let row; columns: displayedColumns;" (click)="onRowClick(row)" [class.clickable]="rowClickable"></tr>
        </table>
        
        <mat-paginator [length]="totalItems" [pageSize]="pageSize" [pageSizeOptions]="[5, 10, 25, 100]"
                       (page)="onPageChange($event)" *ngIf="showPagination">
        </mat-paginator>
      </div>
    </div>
  `,
  styles: [`
    .table-container {
      background: var(--card-bg);
      border-radius: 12px;
      overflow: hidden;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
    }
    .table-toolbar {
      padding: 16px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      border-bottom: 1px solid var(--border-color);
    }
    .search-box {
      display: flex;
      align-items: center;
      gap: 8px;
      padding: 8px 12px;
      background: var(--hover-bg);
      border-radius: 8px;
      min-width: 250px;
    }
    .search-box input {
      border: none;
      background: none;
      outline: none;
      font-size: 14px;
      width: 100%;
      color: var(--text-primary);
    }
    .actions {
      display: flex;
      gap: 8px;
    }
    table {
      width: 100%;
    }
    .clickable {
      cursor: pointer;
    }
    .clickable:hover {
      background: var(--hover-bg);
    }
    ::ng-deep .mat-sort-header-container {
      justify-content: center;
    }
  `]
})
export class DataTableComponent implements OnInit {
  @Input() columns: any[] = [];
  @Input() data: any[] = [];
  @Input() showToolbar: boolean = true;
  @Input() showPagination: boolean = true;
  @Input() pageSize: number = 10;
  @Input() rowClickable: boolean = false;
  @Output() rowClick = new EventEmitter<any>();
  @Output() pageChange = new EventEmitter<PageEvent>();
  @Output() sortChange = new EventEmitter<Sort>();
  
  dataSource = new MatTableDataSource<any>([]);
  displayedColumns: string[] = [];
  totalItems: number = 0;
  
  ngOnInit() {
    this.displayedColumns = this.columns.map(c => c.key);
    this.dataSource.data = this.data;
    this.totalItems = this.data.length;
  }
  
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }
  
  sortData(sort: Sort) {
    this.sortChange.emit(sort);
  }
  
  onPageChange(event: PageEvent) {
    this.pageChange.emit(event);
  }
  
  onRowClick(row: any) {
    if (this.rowClickable) {
      this.rowClick.emit(row);
    }
  }
}