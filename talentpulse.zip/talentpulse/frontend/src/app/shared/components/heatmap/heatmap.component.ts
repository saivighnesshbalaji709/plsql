import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-heatmap',
  template: `
    <div class="heatmap-container">
      <div class="heatmap-header">
        <h3>{{ title }}</h3>
        <div class="legend">
          <span>Low</span>
          <div class="gradient-bar"></div>
          <span>High</span>
        </div>
      </div>
      <div class="heatmap-grid">
        <div class="heatmap-row" *ngFor="let row of data">
          <div class="row-label">{{ row.label }}</div>
          <div class="row-cells">
            <div class="heatmap-cell" *ngFor="let cell of row.cells"
                 [style.background-color]="getColor(cell.value)"
                 [matTooltip]="cell.tooltip || cell.value">
              {{ cell.displayValue || cell.value }}
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .heatmap-container {
      background: var(--card-bg);
      border-radius: 12px;
      padding: 20px;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
    }
    .heatmap-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 20px;
    }
    .heatmap-header h3 {
      margin: 0;
      font-size: 18px;
      font-weight: 600;
    }
    .legend {
      display: flex;
      align-items: center;
      gap: 8px;
      font-size: 12px;
    }
    .gradient-bar {
      width: 100px;
      height: 12px;
      background: linear-gradient(to right, #4CAF50, #FFC107, #f44336);
      border-radius: 6px;
    }
    .heatmap-grid {
      display: flex;
      flex-direction: column;
      gap: 8px;
    }
    .heatmap-row {
      display: flex;
      align-items: center;
      gap: 16px;
    }
    .row-label {
      width: 100px;
      font-size: 14px;
      font-weight: 500;
    }
    .row-cells {
      display: flex;
      gap: 4px;
      flex: 1;
    }
    .heatmap-cell {
      flex: 1;
      padding: 8px;
      text-align: center;
      border-radius: 6px;
      font-size: 12px;
      font-weight: 500;
      cursor: pointer;
      transition: transform 0.2s;
    }
    .heatmap-cell:hover {
      transform: scale(1.05);
    }
  `]
})
export class HeatmapComponent implements OnInit {
  @Input() title: string = 'Assessment Heatmap';
  @Input() data: any[] = [];
  
  ngOnInit() {
    if (!this.data.length) {
      // Sample data
      this.data = [
        { label: 'Python Basics', cells: [
          { value: 85, tooltip: '85% - Excellent' },
          { value: 72, tooltip: '72% - Good' },
          { value: 45, tooltip: '45% - Needs Improvement' }
        ]},
        { label: 'SQL', cells: [
          { value: 78, tooltip: '78% - Good' },
          { value: 68, tooltip: '68% - Average' },
          { value: 55, tooltip: '55% - Below Average' }
        ]},
        { label: 'Web Dev', cells: [
          { value: 92, tooltip: '92% - Excellent' },
          { value: 82, tooltip: '82% - Very Good' },
          { value: 65, tooltip: '65% - Average' }
        ]}
      ];
    }
  }
  
  getColor(value: number): string {
    if (value >= 80) return '#4CAF50';
    if (value >= 60) return '#8BC34A';
    if (value >= 40) return '#FFC107';
    if (value >= 20) return '#FF9800';
    return '#f44336';
  }
}