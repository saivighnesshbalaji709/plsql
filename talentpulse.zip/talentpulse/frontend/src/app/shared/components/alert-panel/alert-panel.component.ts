import { Component, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-alert-panel',
  template: `
    <div class="alert-panel">
      <div class="alert-header">
        <div class="title">
          <mat-icon>notifications_active</mat-icon>
          <h3>{{ title }}</h3>
        </div>
        <div class="badge" *ngIf="alerts.length > 0">{{ alerts.length }}</div>
      </div>
      <div class="alert-list">
        <div class="alert-item" *ngFor="let alert of alerts" [class]="'alert-' + alert.severity">
          <div class="alert-icon">
            <mat-icon *ngIf="alert.severity === 'high'">error</mat-icon>
            <mat-icon *ngIf="alert.severity === 'medium'">warning</mat-icon>
            <mat-icon *ngIf="alert.severity === 'low'">info</mat-icon>
          </div>
          <div class="alert-content">
            <div class="alert-message">{{ alert.message }}</div>
            <div class="alert-meta">
              <span *ngIf="alert.trainee_name">{{ alert.trainee_name }}</span>
              <span class="alert-time">{{ alert.time | date:'short' }}</span>
            </div>
          </div>
          <button mat-icon-button *ngIf="showActions" (click)="onResolve(alert)">
            <mat-icon>check_circle</mat-icon>
          </button>
        </div>
        <div class="no-alerts" *ngIf="alerts.length === 0">
          <mat-icon>check_circle_outline</mat-icon>
          <p>No active alerts</p>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .alert-panel {
      background: var(--card-bg);
      border-radius: 12px;
      overflow: hidden;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
    }
    .alert-header {
      padding: 16px 20px;
      background: linear-gradient(135deg, #667eea, #764ba2);
      color: white;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    .title {
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .title h3 {
      margin: 0;
      font-size: 16px;
      font-weight: 600;
    }
    .badge {
      background: rgba(255, 255, 255, 0.3);
      padding: 4px 8px;
      border-radius: 20px;
      font-size: 12px;
      font-weight: 600;
    }
    .alert-list {
      padding: 8px;
    }
    .alert-item {
      display: flex;
      align-items: center;
      gap: 12px;
      padding: 12px;
      margin-bottom: 8px;
      border-radius: 8px;
      transition: transform 0.2s;
    }
    .alert-item:hover {
      transform: translateX(4px);
    }
    .alert-high {
      background: linear-gradient(135deg, #f44336, #e91e63);
      color: white;
    }
    .alert-medium {
      background: linear-gradient(135deg, #FF9800, #FFC107);
      color: white;
    }
    .alert-low {
      background: linear-gradient(135deg, #4CAF50, #8BC34A);
      color: white;
    }
    .alert-icon mat-icon {
      font-size: 24px;
      width: 24px;
      height: 24px;
    }
    .alert-content {
      flex: 1;
    }
    .alert-message {
      font-size: 14px;
      font-weight: 500;
      margin-bottom: 4px;
    }
    .alert-meta {
      font-size: 11px;
      opacity: 0.8;
      display: flex;
      gap: 12px;
    }
    .no-alerts {
      text-align: center;
      padding: 40px;
      color: var(--text-secondary);
    }
    .no-alerts mat-icon {
      font-size: 48px;
      width: 48px;
      height: 48px;
      margin-bottom: 16px;
    }
  `]
})
export class AlertPanelComponent {
  @Input() title: string = 'Alerts & Notifications';
  @Input() alerts: any[] = [];
  @Input() showActions: boolean = true;
  @Output() resolve = new EventEmitter<any>();
  
  onResolve(alert: any) {
    this.resolve.emit(alert);
  }
}