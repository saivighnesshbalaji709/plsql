import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-kpi-card',
  template: `
    <div class="kpi-card" [class.clickable]="clickable" (click)="onClick()">
      <div class="kpi-icon" [style.background]="iconBgColor">
        <mat-icon>{{ icon }}</mat-icon>
      </div>
      <div class="kpi-content">
        <div class="kpi-value">{{ value }}</div>
        <div class="kpi-label">{{ label }}</div>
        <div class="kpi-trend" *ngIf="trend" [class.positive]="trend > 0" [class.negative]="trend < 0">
          <mat-icon>{{ trend > 0 ? 'trending_up' : 'trending_down' }}</mat-icon>
          <span>{{ trend > 0 ? '+' : '' }}{{ trend }}%</span>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .kpi-card {
      background: var(--card-bg);
      border-radius: 16px;
      padding: 20px;
      display: flex;
      align-items: center;
      gap: 16px;
      transition: all 0.3s ease;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
    }
    .kpi-card:hover {
      transform: translateY(-4px);
      box-shadow: 0 8px 24px rgba(0, 0, 0, 0.15);
    }
    .kpi-card.clickable {
      cursor: pointer;
    }
    .kpi-icon {
      width: 56px;
      height: 56px;
      border-radius: 12px;
      display: flex;
      align-items: center;
      justify-content: center;
      background: linear-gradient(135deg, #667eea, #764ba2);
    }
    .kpi-icon mat-icon {
      font-size: 28px;
      width: 28px;
      height: 28px;
      color: white;
    }
    .kpi-content {
      flex: 1;
    }
    .kpi-value {
      font-size: 28px;
      font-weight: 700;
      color: var(--text-primary);
      margin-bottom: 4px;
    }
    .kpi-label {
      font-size: 14px;
      color: var(--text-secondary);
    }
    .kpi-trend {
      font-size: 12px;
      margin-top: 8px;
      display: flex;
      align-items: center;
      gap: 4px;
    }
    .kpi-trend.positive {
      color: #4CAF50;
    }
    .kpi-trend.negative {
      color: #f44336;
    }
    .kpi-trend mat-icon {
      font-size: 16px;
      width: 16px;
      height: 16px;
    }
  `]
})
export class KpiCardComponent {
  @Input() icon: string = 'analytics';
  @Input() value: string | number = '0';
  @Input() label: string = '';
  @Input() trend?: number;
  @Input() iconBgColor: string = 'linear-gradient(135deg, #667eea, #764ba2)';
  @Input() clickable: boolean = false;
  @Input() onClick: () => void = () => {};
}