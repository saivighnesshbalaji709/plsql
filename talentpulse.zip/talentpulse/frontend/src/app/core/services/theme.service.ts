import { Injectable, Renderer2, RendererFactory2 } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ThemeService {
  private renderer: Renderer2;
  private isDark = false;
  
  constructor(rendererFactory: RendererFactory2) {
    this.renderer = rendererFactory.createRenderer(null, null);
  }
  
  initializeTheme(): void {
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme === 'dark') {
      this.enableDarkMode();
    } else if (savedTheme === 'light') {
      this.enableLightMode();
    } else {
      // Check system preference
      const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
      if (prefersDark) {
        this.enableDarkMode();
      } else {
        this.enableLightMode();
      }
    }
  }
  
  toggleTheme(): void {
    if (this.isDark) {
      this.enableLightMode();
    } else {
      this.enableDarkMode();
    }
  }
  
  enableDarkMode(): void {
    this.renderer.setAttribute(document.documentElement, 'data-theme', 'dark');
    localStorage.setItem('theme', 'dark');
    this.isDark = true;
  }
  
  enableLightMode(): void {
    this.renderer.removeAttribute(document.documentElement, 'data-theme');
    localStorage.setItem('theme', 'light');
    this.isDark = false;
  }
  
  setTheme(theme: string): void {
    if (theme === 'dark') {
      this.enableDarkMode();
    } else {
      this.enableLightMode();
    }
  }
  
  isDarkMode(): boolean {
    return this.isDark;
  }
}