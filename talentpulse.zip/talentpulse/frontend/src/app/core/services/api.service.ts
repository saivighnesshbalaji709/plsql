import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ApiService {
  private baseUrl = 'http://localhost:8000/api';
  
  constructor(private http: HttpClient) {}
  
  // Trainees
  getTrainees(params?: any): Observable<any> {
    let httpParams = new HttpParams();
    if (params) {
      Object.keys(params).forEach(key => {
        if (params[key] !== undefined && params[key] !== null) {
          httpParams = httpParams.set(key, params[key]);
        }
      });
    }
    return this.http.get(`${this.baseUrl}/trainees`, { params: httpParams });
  }
  
  getTrainee(id: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/trainees/${id}`);
  }
  
  createTrainee(trainee: any): Observable<any> {
    return this.http.post(`${this.baseUrl}/trainees/`, trainee);
  }
  
  getTraineeAIInsights(id: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/trainees/${id}/ai-insights`);
  }
  
  // Batches
  getBatches(params?: any): Observable<any> {
    let httpParams = new HttpParams();
    if (params) {
      Object.keys(params).forEach(key => {
        if (params[key] !== undefined && params[key] !== null) {
          httpParams = httpParams.set(key, params[key]);
        }
      });
    }
    return this.http.get(`${this.baseUrl}/batches`, { params: httpParams });
  }
  
  getBatch(id: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/batches/${id}`);
  }
  
  getBatchPerformance(id: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/batches/${id}/performance`);
  }
  
  // Assessments
  getAssessments(params?: any): Observable<any> {
    let httpParams = new HttpParams();
    if (params) {
      Object.keys(params).forEach(key => {
        if (params[key] !== undefined && params[key] !== null) {
          httpParams = httpParams.set(key, params[key]);
        }
      });
    }
    return this.http.get(`${this.baseUrl}/assessments`, { params: httpParams });
  }
  
  submitAttempt(assessmentId: number, attempt: any): Observable<any> {
    return this.http.post(`${this.baseUrl}/assessments/${assessmentId}/attempts`, attempt);
  }
  
  // Insights
  getDashboardInsights(role: string): Observable<any> {
    return this.http.get(`${this.baseUrl}/insights/dashboard/${role}`);
  }
  
  getDropoutRisks(): Observable<any> {
    return this.http.get(`${this.baseUrl}/insights/dropout-risks`);
  }
  
  // Reports
  generateReport(reportRequest: any): Observable<any> {
    return this.http.post(`${this.baseUrl}/reports/generate`, reportRequest);
  }
  
  // Users (Admin only)
  getUsers(params?: any): Observable<any> {
    let httpParams = new HttpParams();
    if (params) {
      Object.keys(params).forEach(key => {
        if (params[key] !== undefined && params[key] !== null) {
          httpParams = httpParams.set(key, params[key]);
        }
      });
    }
    return this.http.get(`${this.baseUrl}/users`, { params: httpParams });
  }
  
  createUser(user: any): Observable<any> {
    return this.http.post(`${this.baseUrl}/users/`, user);
  }
  
  updateUser(id: number, user: any): Observable<any> {
    return this.http.put(`${this.baseUrl}/users/${id}`, user);
  }
  
  deleteUser(id: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}/users/${id}`);
  }
  
  getAuditLogs(): Observable<any> {
    return this.http.get(`${this.baseUrl}/users/audit-logs`);
  }
  
  // Exports
  exportTraineesToExcel(batchId?: number): Observable<Blob> {
    let url = `${this.baseUrl}/exports/excel/trainees`;
    if (batchId) {
      url += `?batch_id=${batchId}`;
    }
    return this.http.get(url, { responseType: 'blob' });
  }
  
  exportBatchesToExcel(): Observable<Blob> {
    return this.http.get(`${this.baseUrl}/exports/excel/batches`, { responseType: 'blob' });
  }
  
  exportPerformancePDF(traineeId: number): Observable<Blob> {
    return this.http.get(`${this.baseUrl}/exports/pdf/performance/${traineeId}`, { responseType: 'blob' });
  }
}