import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, Router } from '@angular/router';
import { AuthService } from '../services/auth.service';

@Injectable({
  providedIn: 'root'
})
export class RoleGuard implements CanActivate {
  
  constructor(
    private authService: AuthService,
    private router: Router
  ) {}
  
  canActivate(route: ActivatedRouteSnapshot): boolean {
    const requiredRoles = route.data['roles'] as Array<string>;
    const userRole = this.authService.getUserRole();
    
    if (!userRole) {
      this.router.navigate(['/login']);
      return false;
    }
    
    if (requiredRoles && requiredRoles.includes(userRole)) {
      return true;
    }
    
    // Redirect to appropriate dashboard based on role
    switch (userRole) {
      case 'trainer':
        this.router.navigate(['/trainer']);
        break;
      case 'ld_hr':
        this.router.navigate(['/ld-hr']);
        break;
      case 'stakeholder':
        this.router.navigate(['/stakeholder']);
        break;
      case 'admin':
        this.router.navigate(['/admin']);
        break;
      default:
        this.router.navigate(['/login']);
    }
    
    return false;
  }
}