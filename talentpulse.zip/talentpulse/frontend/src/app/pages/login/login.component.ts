import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../core/services/auth.service';
import { NotificationService } from '../../core/services/notification.service';
import { ThemeService } from '../../core/services/theme.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  selectedRole: string = 'trainer';
  isLoading = false;
  showPassword = false;
  
  roles = [
    { value: 'trainer', label: 'Trainer', icon: 'school', color: '#4CAF50' },
    { value: 'ld_hr', label: 'LD/HR', icon: 'people', color: '#2196F3' },
    { value: 'stakeholder', label: 'Business Stakeholder', icon: 'business', color: '#FF9800' },
    { value: 'admin', label: 'Administrator', icon: 'admin_panel_settings', color: '#9C27B0' }
  ];

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private router: Router,
    private notificationService: NotificationService,
    public themeService: ThemeService
  ) {
    this.loginForm = this.fb.group({
      username: ['', Validators.required],
      password: ['', Validators.required]
    });
  }

  ngOnInit() {
    // Redirect if already logged in
    if (this.authService.isLoggedIn()) {
      this.redirectBasedOnRole();
    }
  }

  selectRole(role: string) {
    this.selectedRole = role;
  }

  onSubmit() {
    if (this.loginForm.invalid) {
      return;
    }

    this.isLoading = true;
    const credentials = {
      username: this.loginForm.value.username,
      password: this.loginForm.value.password,
      role: this.selectedRole
    };

    this.authService.login(credentials).subscribe({
      next: (response) => {
        this.isLoading = false;
        this.notificationService.showSuccess('Login successful!');
        this.redirectBasedOnRole();
      },
      error: (error) => {
        this.isLoading = false;
        this.notificationService.showError(error.error?.detail || 'Login failed');
      }
    });
  }

  redirectBasedOnRole() {
    const userRole = this.authService.getUserRole();
    switch (userRole) {
      case 'trainer':
        this.router.navigate(['/trainer']);
        break;
      case 'ld_hr':
        this.router.navigate(['/ld-hr']);
        break;
      case 'stakeholder':
        this.router.navigate(['/stakeholder']);
        break;
      case 'admin':
        this.router.navigate(['/admin']);
        break;
      default:
        this.router.navigate(['/login']);
    }
  }

  toggleTheme() {
    this.themeService.toggleTheme();
  }
}