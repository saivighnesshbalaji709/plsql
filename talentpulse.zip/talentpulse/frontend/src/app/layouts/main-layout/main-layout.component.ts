import { Component, OnInit } from '@angular/core';
import { AuthService, User } from '../../core/services/auth.service';
import { ThemeService } from '../../core/services/theme.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-main-layout',
  templateUrl: './main-layout.component.html',
  styleUrls: ['./main-layout.component.css']
})
export class MainLayoutComponent implements OnInit {
  isExpanded = true;
  currentUser: User | null = null;
  
  navItems: any[] = [];
  
  constructor(
    private authService: AuthService,
    public themeService: ThemeService,
    private router: Router
  ) {}
  
  ngOnInit() {
    this.currentUser = this.authService.getCurrentUser();
    this.setupNavigation();
  }
  
  setupNavigation() {
    const role = this.currentUser?.role;
    
    if (role === 'trainer') {
      this.navItems = [
        { label: 'Dashboard', icon: 'dashboard', route: '/trainer' },
        { label: 'Batches', icon: 'groups', route: '/batches' },
        { label: 'Trainees', icon: 'people', route: '/trainees' },
        { label: 'AI Insights', icon: 'psychology', route: '/ai-insights' },
        { label: 'Reports', icon: 'assessment', route: '/reports' }
      ];
    } else if (role === 'ld_hr') {
      this.navItems = [
        { label: 'Dashboard', icon: 'dashboard', route: '/ld-hr' },
        { label: 'All Batches', icon: 'groups', route: '/batches' },
        { label: 'Performance Analytics', icon: 'insights', route: '/analytics' },
        { label: 'AI Insights', icon: 'psychology', route: '/ai-insights' },
        { label: 'Reports', icon: 'assessment', route: '/reports' }
      ];
    } else if (role === 'stakeholder') {
      this.navItems = [
        { label: 'Dashboard', icon: 'dashboard', route: '/stakeholder' },
        { label: 'Batch Overview', icon: 'groups', route: '/batches' },
        { label: 'Deployment Readiness', icon: 'rocket_launch', route: '/readiness' },
        { label: 'Strategic Reports', icon: 'assessment', route: '/reports' }
      ];
    } else if (role === 'admin') {
      this.navItems = [
        { label: 'Dashboard', icon: 'dashboard', route: '/admin' },
        { label: 'User Management', icon: 'admin_panel_settings', route: '/users' },
        { label: 'System Health', icon: 'health_and_safety', route: '/health' },
        { label: 'Audit Logs', icon: 'receipt_long', route: '/audit' },
        { label: 'Reports', icon: 'assessment', route: '/reports' }
      ];
    }
  }
  
  toggleSidenav() {
    this.isExpanded = !this.isExpanded;
  }
  
  getUserInitial(): string {
    if (this.currentUser?.full_name) {
      return this.currentUser.full_name.charAt(0).toUpperCase();
    }
    return 'U';
  }
  
  logout() {
    this.authService.logout();
  }
}