import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

// Material Imports
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatListModule } from '@angular/material/list';
import { MatCardModule } from '@angular/material/card';
import { MatTableModule } from '@angular/material/table';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSortModule } from '@angular/material/sort';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatMenuModule } from '@angular/material/menu';
import { MatChipsModule } from '@angular/material/chips';
import { MatTabsModule } from '@angular/material/tabs';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatBadgeModule } from '@angular/material/badge';
import { MatGridListModule } from '@angular/material/grid-list';

// Componentsimport { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { LoginComponent } from './pages/login/login.component';
import { TrainerDashboardComponent } from './pages/trainer-dashboard/trainer-dashboard.component';
import { LdDashboardComponent } from './pages/ld-dashboard/ld-dashboard.component';
import { StakeholderDashboardComponent } from './pages/stakeholder-dashboard/stakeholder-dashboard.component';
import { AdminDashboardComponent } from './pages/admin-dashboard/admin-dashboard.component';
import { TraineeDetailComponent } from './pages/trainee-detail/trainee-detail.component';
import { BatchDetailComponent } from './pages/batch-detail/batch-detail.component';
import { AiInsightsComponent } from './pages/ai-insights/ai-insights.component';
import { ReportsComponent } from './pages/reports/reports.component';
import { UserManagementComponent } from './pages/user-management/user-management.component';
import { MainLayoutComponent } from './layouts/main-layout/main-layout.component';

// Shared Components
import { KpiCardComponent } from './shared/components/kpi-card/kpi-card.component';
import { HeatmapComponent } from './shared/components/heatmap/heatmap.component';
import { DataTableComponent } from './shared/components/data-table/data-table.component';
import { AlertPanelComponent } from './shared/components/alert-panel/alert-panel.component';

// Services
import { AuthInterceptor } from './core/interceptors/auth.interceptor';
import { AuthService } from './core/services/auth.service';
import { ApiService } from './core/services/api.service';
import { ThemeService } from './core/services/theme.service';
import { NotificationService } from './core/services/notification.service';

// Guards
import { AuthGuard } from './core/guards/auth.guard';
import { RoleGuard } from './core/guards/role.guard';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    TrainerDashboardComponent,
    LdDashboardComponent,
    StakeholderDashboardComponent,
    AdminDashboardComponent,
    TraineeDetailComponent,
    BatchDetailComponent,
    AiInsightsComponent,
    ReportsComponent,
    UserManagementComponent,
    MainLayoutComponent,
    KpiCardComponent,
    HeatmapComponent,
    DataTableComponent,
    AlertPanelComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule,
    AppRoutingModule,
    // Material
    MatToolbarModule,
    MatSidenavModule,
    MatButtonModule,
    MatIconModule,
    MatListModule,
    MatCardModule,
    MatTableModule,
    MatPaginatorModule,
    MatSortModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatProgressSpinnerModule,
    MatSnackBarModule,
    MatTooltipModule,
    MatMenuModule,
    MatChipsModule,
    MatTabsModule,
    MatExpansionModule,
    MatSlideToggleModule,
    MatBadgeModule,
    MatGridListModule
  ],
  providers: [
    AuthService,
    ApiService,
    ThemeService,
    NotificationService,
    AuthGuard,
    RoleGuard,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: AuthInterceptor,
      multi: true
    }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }