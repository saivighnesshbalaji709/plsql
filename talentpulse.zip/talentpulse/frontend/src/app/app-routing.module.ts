import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './pages/login/login.component';
import { MainLayoutComponent } from './layouts/main-layout/main-layout.component';
import { TrainerDashboardComponent } from './pages/trainer-dashboard/trainer-dashboard.component';
import { LdDashboardComponent } from './pages/ld-dashboard/ld-dashboard.component';
import { StakeholderDashboardComponent } from './pages/stakeholder-dashboard/stakeholder-dashboard.component';
import { AdminDashboardComponent } from './pages/admin-dashboard/admin-dashboard.component';
import { TraineeDetailComponent } from './pages/trainee-detail/trainee-detail.component';
import { BatchDetailComponent } from './pages/batch-detail/batch-detail.component';
import { AiInsightsComponent } from './pages/ai-insights/ai-insights.component';
import { ReportsComponent } from './pages/reports/reports.component';
import { UserManagementComponent } from './pages/user-management/user-management.component';
import { AuthGuard } from './core/guards/auth.guard';
import { RoleGuard } from './core/guards/role.guard';

const routes: Routes = [
  { path: 'login', component: LoginComponent },
  {
    path: '',
    component: MainLayoutComponent,
    canActivate: [AuthGuard],
    children: [
      {
        path: 'trainer',
        component: TrainerDashboardComponent,
        canActivate: [RoleGuard],
        data: { roles: ['trainer'] }
      },
      {
        path: 'ld-hr',
        component: LdDashboardComponent,
        canActivate: [RoleGuard],
        data: { roles: ['ld_hr'] }
      },
      {
        path: 'stakeholder',
        component: StakeholderDashboardComponent,
        canActivate: [RoleGuard],
        data: { roles: ['stakeholder'] }
      },
      {
        path: 'admin',
        component: AdminDashboardComponent,
        canActivate: [RoleGuard],
        data: { roles: ['admin'] }
      },
      {
        path: 'trainee/:id',
        component: TraineeDetailComponent
      },
      {
        path: 'batch/:id',
        component: BatchDetailComponent
      },
      {
        path: 'ai-insights',
        component: AiInsightsComponent
      },
      {
        path: 'reports',
        component: ReportsComponent
      },
      {
        path: 'users',
        component: UserManagementComponent,
        canActivate: [RoleGuard],
        data: { roles: ['admin'] }
      },
      { path: '', redirectTo: '/trainer', pathMatch: 'full' }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }