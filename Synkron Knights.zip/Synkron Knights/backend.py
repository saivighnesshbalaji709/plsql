from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.templating import Jinja2Templates
import asyncio

from workflow import LegalRiskWorkflow
from config import *
from azure.identity import ClientSecretCredential
from azure.ai.agents import AgentsClient

app = FastAPI()
templates = Jinja2Templates(directory="templates")

# Initialize Azure client once
credential = ClientSecretCredential(
    TENANT_ID,
    CLIENT_ID,
    CLIENT_SECRET
)

client = AgentsClient(
    endpoint=PROJECT_ENDPOINT,
    credential=credential
)

workflow = LegalRiskWorkflow(client, AGENT_ID)

@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

@app.post("/analyze")
async def analyze_case(request: Request):
    try:
        data = await request.json()
        print("📥 Received input:", data)

        result = await workflow.run(data)
        print("📤 Sending result:", result)

        return JSONResponse(content=result)

    except Exception as e:
        print("❌ ERROR:", str(e))
        return JSONResponse(
            status_code=500,
            content={"error": str(e)}
        )
