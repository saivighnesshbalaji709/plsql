from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.templating import Jinja2Templates
from azure.identity import ClientSecretCredential
from azure.ai.agents import AgentsClient
from law_feeds import fetch_law_news

import uuid

from workflow import LegalRiskWorkflow
from config import *

app = FastAPI()
templates = Jinja2Templates(directory="templates")

# Azure Agent Client
credential = ClientSecretCredential(
    TENANT_ID,
    CLIENT_ID,
    CLIENT_SECRET
)

client = AgentsClient(
    endpoint=PROJECT_ENDPOINT,
    credential=credential
)

workflow = LegalRiskWorkflow(client, AGENT_ID)

# Store last case result for insights
LAST_RESULT = {}

@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

@app.post("/analyze")
async def analyze_case(request: Request):
    try:
        data = await request.json()
        case_text = data.get("text")

        result = await workflow.run(case_text)

        # Save for dashboard
        LAST_RESULT["data"] = result

        return JSONResponse(content=result)

    except Exception as e:
        print("❌ ERROR:", str(e))
        return JSONResponse(status_code=500, content={"error": str(e)})

@app.get("/dashboard", response_class=HTMLResponse)
async def dashboard(request: Request):
    return templates.TemplateResponse("dashboard.html", {"request":request})

@app.get("/insights")
async def insights():
    r = LAST_RESULT.get("data")
    if not r:
        return {"categories":{}, "countries":{}, "laws":{}}

    text = r["summary"] + " " + r["factors"]

    categories = {
        "Data Protection": 35 if "GDPR" in text or "LGPD" in text else 15,
        "Sanctions": 30 if "OFAC" in text else 10,
        "AML": 25 if "AML" in text else 10,
        "IP": 20 if "IP" in text else 8,
        "Employment": 15
    }

    countries = {}
    for c in ["US","Germany","India","Brazil","Nigeria","UK","China"]:
        countries[c] = 30 if c.lower() in text.lower() else 10

    laws = {
        "GDPR": 40 if "GDPR" in text else 10,
        "LGPD": 35 if "LGPD" in text else 10,
        "DPDP India": 30 if "India" in text else 10,
        "HIPAA": 25 if "HIPAA" in text else 10,
        "OFAC": 35 if "OFAC" in text else 10
    }

    return {"categories":categories,"countries":countries,"laws":laws}


@app.get("/laws")
async def law_radar():
    return fetch_law_news()

