import json
import re

def clean_text(text: str) -> str:
    if not text:
        return ""

    # Remove ```json, ``` and similar markers
    text = re.sub(r"```.*?\n", "", text)
    text = text.replace("```", "")
    text = text.replace("json\n", "")
    text = text.strip()

    return text