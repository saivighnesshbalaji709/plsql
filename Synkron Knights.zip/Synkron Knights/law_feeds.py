import feedparser
import time

FEEDS = [
    "https://ec.europa.eu/info/news/news-archive_en?rss",           # EU legal & policy
    "https://www.federalregister.gov/documents/search.rss",        # US Federal Register
    "https://ico.org.uk/rss/news.xml",                              # UK ICO (data protection)
    "https://www.gov.br/anpd/pt-br/rss.xml",                        # Brazil LGPD authority
    "https://www.meity.gov.in/rss.xml"                              # India IT & data policy
]

CACHE = {"data": [], "time": 0}

def fetch_law_news():
    global CACHE
    # Refresh every 30 minutes
    if time.time() - CACHE["time"] < 1800:
        return CACHE["data"]

    news = []
    for url in FEEDS:
        try:
            feed = feedparser.parse(url)
            for entry in feed.entries[:5]:
                title = entry.title
                news.append(title)
        except:
            pass

    CACHE = {
        "data": news[:20],
        "time": time.time()
    }
    return CACHE["data"]
