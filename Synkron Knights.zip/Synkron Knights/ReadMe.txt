To execute the agent, follow the mentioned steps:

1. Run the command: python -m pip install -r requirements.txt

2. Run the command:python -m uvicorn backend:app --reload

3. Now open http://127.0.0.1:8000/ in your local browser for viewing the prototype of the Agent