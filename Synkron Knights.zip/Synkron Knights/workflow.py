import re
from agents import Agent
from utils import clean_text

class LegalRiskWorkflow:
    def __init__(self, client, agent_id):
        self.agent = Agent(client, agent_id)
        self.client = client

    def create_thread(self):
        return self.client.threads.create().id

    def extract_score(self, text):
        match = re.search(r"(\d{1,3})\s*/\s*100", text)
        return int(match.group(1)) if match else 65

    def risk_level(self, score):
        if score >= 75: return "HIGH"
        if score >= 45: return "MEDIUM"
        return "LOW"

    async def run(self, case_text):
        thread = self.create_thread()

        prompt = f"""
You are a senior cross-border compliance analyst.

Analyze the business scenario below.

You must:
- Identify the countries involved
- Identify the exact regulations that apply (GDPR, LGPD, DPDP Act, HIPAA, OFAC, AML, Schrems II, etc.)
- Explain legal exposure in practical business terms
- Estimate financial penalty exposure where possible
- Assign an overall risk score from 0 to 100 (include it like 82/100)
- Provide a what-if analysis (what happens if a risky country or data type is removed)
- Give a final recommendation: approve, approve with conditions, or reject

Do not use bullet points, markdown, or symbols like * or #.
Write like a legal advisory memo to a board of directors.

Business case:
{case_text}
"""

        raw = await self.agent.run(thread, prompt)
        text = clean_text(raw)

        score = self.extract_score(text)
        level = self.risk_level(score)

        # Rough semantic slicing
        sections = re.split(r"\n\n+", text)

        return {
            "summary": sections[0] if len(sections) > 0 else text,
            "factors": sections[1] if len(sections) > 1 else "",
            "score": score,
            "level": level,
            "what_if": sections[2] if len(sections) > 2 else "",
            "decision": sections[-1]
        }
