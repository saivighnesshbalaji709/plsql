import json
from agents import Agent
from utils import clean_text

class LegalRiskWorkflow:
    def __init__(self, client, agent_id):
        self.analyzer = Agent(client, agent_id)
        self.risk_agent = Agent(client, agent_id)
        self.decision_agent = Agent(client, agent_id)
        self.client = client

    def create_thread(self):
        return self.client.threads.create().id

    async def run(self, input_data):

        # STEP 1 — Analyze facts
        thread = self.create_thread()
        analyze_prompt = f"""
You are a Legal Analyzer Agent.

Analyze the case and return JSON with:
- countries
- laws
- data_types
- cross_border (true/false)

Input:
{json.dumps(input_data, indent=2)}

Return ONLY JSON.
"""
        analysis = await self.analyzer.run(thread, analyze_prompt)

        # STEP 2 — Risk scoring
        thread = self.create_thread()
        risk_prompt = f"""
You are a Risk Scoring Agent.

Based on this analysis:
{analysis}

Return JSON with:
- regulatory_risk (LOW/MEDIUM/HIGH)
- operational_risk (LOW/MEDIUM/HIGH)
- overall_risk (LOW/MEDIUM/HIGH)
"""
        risk = await self.risk_agent.run(thread, risk_prompt)

        # STEP 3 — Final decision
        thread = self.create_thread()
        decision_prompt = f"""
You are an Executive Decision Agent.

Based on risks below:
{risk}

Return JSON:
- decision (APPROVED / CONDITIONAL / REJECTED)
- reason
- conditions (if any)
"""
        decision = await self.decision_agent.run(thread, decision_prompt)

        return {
            "analysis": clean_text(analysis),
            "risk": clean_text(risk),
            "decision": clean_text(decision)
        }
    

